# Project Instructions — premier-sbp-tools

On-terminal control software for PremierBet / BetRoyal self-service betting kiosks
("aparati"). Runs on Linux (primary) and Windows kiosks. NOT a Django/web app —
the SessionStart auto-detector is wrong. `manage.py` is a custom process supervisor,
not Django's. Version 5.5.0.

## Tech Stack
- **Python 3** for orchestration & most services; **Python 2** for `services/acceptor.py`
  (started as `python2` in `manage.py`). Acceptor code MUST stay py2-compatible
  (`.encode('hex')`, `__nonzero__`, chr-based byte strings).
- **Tornado** — local HTTP microservices (printer, acceptor APIs on localhost).
- **pyserial** — hardware I/O: coin acceptor (ccTalk), bill acceptor (ID003), printer.
- **redis** — local IPC / job queues between processes (`brpop`/`lpush`).
- **reportlab + PIL** — ticket/receipt rendering. **requests** — backend API calls.
- **stunnel** — TLS tunnel for acceptor + backdoor traffic. **sendgrid** — admin alerts.
- Google **Chrome --kiosk** — the actual betting UI (launched by `services/splitter.py`).
- No dependency manifest, no test suite, no git repo (see Gaps).

## Architecture
`manage.py` (supervisor) kills then re-spawns a fleet of independent processes based on
`--type` (atm | shop | backdoor-server | dev). Processes are decoupled — they talk via
**local redis queues** and **local HTTP** (Tornado on 127.0.0.1). Hardware via serial.
Remote ops via reverse-SSH "backdoor" tunnels + a backdoor-server.

## Project Structure
- `manage.py` — supervisor / CLI entry point (start, install, update, remote).
- `config.py` — global config (shared, committed). `client_config.py` — per-terminal
  hardware config (serial ports, shop/user IDs, kiosk URLs).
- `services/` — long-running processes: `acceptor.py` (py2, coin/bill money intake),
  `mmacceptor.py`, `printer.py` (Tornado print server), `splitter.py` (Chrome kiosk +
  touchscreen remap), `backdoor-client.py` / `backdoor-server.py`.
- `daemons/` — redis-queue consumers: `ivc-*-printed-tickets.py` batch-POST printed
  tickets to reporting APIs; `backdoor-client-polling.py` polls for remote commands.
- `constants/` — hardware protocol tables: `cctalk_headers.py`, `id003_headers.py`,
  `money_slots.py`.
- `utilities/` — shared helpers: `extra.py` (`@doasync`, `logger`, process mgmt,
  `send_mail`), `service.py` (HTTP + JSON status), `connectors.py` (Serial wrapper),
  `database.py` (redis), `printer.py` (Ticket/escpos), `string.py` (colors, compress).
- `var/` — runtime state: `db/` (sqlite), `log/`, `lock/`, `pid/`. Not source.
- `install/` (linux.sh, chrome .deb), `extras/`, `scheduled-tasks/`.

## Build & Run
- Start a terminal: `python3 manage.py -a -t atm` (or `shop`, `backdoor-server`).
- Dev mode: `python3 manage.py -a -t dev -o 127.0.0.1`.
- Install: `python3 manage.py -i`. Self-update: `python3 manage.py -u`.
- Remote command: `python3 manage.py -t remote -c user@host`.
- No automated tests exist. Verify changes against real/dev hardware or `-t dev`.

## Conventions
- **Indentation is TABS**, not spaces — match existing files exactly.
- snake_case functions/modules; PascalCase classes; kebab-case for runnable scripts
  (`backdoor-client.py`, `ivc-sportsbetting-printed-tickets.py`).
- `@doasync` runs a function in a daemon thread. `logger('name')` → rotating file in
  `var/log/`. Background work loops on redis queues.
- Cross-platform branches everywhere: `config.LINUX_PLATFORM` / `config.WINDOWS_PLATFORM`.
- Per-machine settings belong in `client_config.py`, shared in `config.py`.

## Gaps & Cautions (do not regress)
- **Secrets are hardcoded in `config.py`** (SendGrid API key, SECRET_COOKIE/SALT, redis
  password) and in `manage.py` (`premier:sbptools` update creds). Don't add more; prefer
  env vars / a secret file when touching these. Treat existing ones as compromised.
- `DEBUG = True` ships in `config.py`.
- No requirements file — adding deps means updating `install/linux.sh` + Windows install.
- Keep `acceptor.py` Python-2-compatible until it is intentionally ported.
