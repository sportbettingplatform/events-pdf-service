__author__ = "Nemanja Adamov"
__copyright__ = "Copyright 2017-2019, Nemanja Adamov"
__credits__ = ["Nemanja Adamov"]
__version__ = "5.5.0"
__maintainer__ = "Nemanja Adamov"
__email__ = "nemanja.d.adamov@gmail.com"
__status__ = "Production"
