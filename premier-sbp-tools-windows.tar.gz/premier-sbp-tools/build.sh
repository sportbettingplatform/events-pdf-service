#!/usr/bin/env bash
#
# build.sh — package premier-sbp-tools and publish it for `curl -O` installs.
#
# Upload target:   admin@54.154.6.252 -p 9999  ->  /home/admin/events-pdf-service
# Download domain: https://dopune.betroyal.casino   (same box, HTTP)
#
# Always the SAME filename (no timestamp) so the curl URL is fixed:
#   premier-sbp-tools-linux.tar.gz   (package)
#   premier-sbp-tools-linux.sh       (installer)
#
# What it does:
#   1. Stages the project into a clean tree (drops runtime state and junk).
#   2. Builds  dist/premier-sbp-tools-linux.tar.gz
#   3. Uploads it (+ installer) into the admin home dir (no sudo, no /tmp).
#   4. Prints the terminal install commands.
#
# Install on a terminal (what this produces):
#   curl -O https://dopune.betroyal.casino/premier-sbp-tools-linux.tar.gz
#   sudo tar xzf premier-sbp-tools-linux.tar.gz -C /
#   sudo manage-premier-sbp -a -t <atm|shop> -o <server_ip>
#
# Defaults: client_config.py (per-terminal hardware config) IS packaged. The
# bundled Chrome .deb (~94MB) is NOT. Use --no-client-config to drop it, or
# --with-chrome to also bundle the .deb.
#
# Usage:
#   ./build.sh                  # build + upload (includes client_config.py)
#   ./build.sh --no-upload      # build the tarball only
#   ./build.sh -y               # don't ask for confirmation
#   ./build.sh --no-client-config   # build WITHOUT client_config.py
#   ./build.sh --with-chrome        # also bundle the Chrome .deb
#
# Override without editing the file:
#   REMOTE_HOST=1.2.3.4 REMOTE_PORT=22 REMOTE_DEST=/home/admin/x \
#   DOWNLOAD_URL=https://example.com ./build.sh

set -euo pipefail

# ----------------------------------------------------------------------------
# Target — override via environment variables.
# ----------------------------------------------------------------------------
REMOTE_USER="${REMOTE_USER:-admin}"
REMOTE_HOST="${REMOTE_HOST:-54.154.6.252}"              # SSH host (proven working)
REMOTE_PORT="${REMOTE_PORT:-9999}"
REMOTE_DEST="${REMOTE_DEST:-/home/admin/events-pdf-service}"   # upload dir (home, no sudo)
DOWNLOAD_URL="${DOWNLOAD_URL:-https://dopune.betroyal.casino}" # base URL terminals curl from
DOWNLOAD_AUTH="${DOWNLOAD_AUTH:-}"                      # optional HTTP basic auth "user:pass"

# Stable, version-independent names so the curl URL never changes.
TARBALL="premier-sbp-tools-linux.tar.gz"
INSTALLER="premier-sbp-tools-linux.sh"
WIN_TARBALL="premier-sbp-tools-windows.tar.gz"     # same content (Python is cross-platform)
WIN_INSTALLER="premier-sbp-tools-windows.cmd"      # Win10 native curl.exe + tar.exe

# ----------------------------------------------------------------------------
# Locals
# ----------------------------------------------------------------------------
PROJECT_NAME="premier-sbp-tools"
PROJECT_ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
VERSION="$(grep -E '__version__' "$PROJECT_ROOT/__init__.py" | head -1 | sed -E 's/.*"([^"]+)".*/\1/')"
[ -n "$VERSION" ] || VERSION="unknown"
DIST_DIR="$PROJECT_ROOT/dist"

WITH_CHROME=0
WITH_CLIENT_CONFIG=1     # default: package client_config.py (use --no-client-config to drop)
ASSUME_YES=0
DO_UPLOAD=1

# colors — use $'...' so the ESC byte is real (renders in printf AND heredocs).
if [ -t 1 ]; then
    C_G=$'\033[0;32m'; C_Y=$'\033[0;33m'; C_R=$'\033[0;31m'; C_B=$'\033[0;34m'; C_0=$'\033[0m'
else
    C_G=""; C_Y=""; C_R=""; C_B=""; C_0=""
fi
info() { printf "%s[*]%s %s\n" "$C_G" "$C_0" "$*"; }
warn() { printf "%s[!]%s %s\n" "$C_Y" "$C_0" "$*"; }
err()  { printf "%s[x]%s %s\n" "$C_R" "$C_0" "$*" >&2; }
step() { printf "\n%s==>%s %s\n" "$C_B" "$C_0" "$*"; }

usage() { sed -n '2,40p' "$0" | sed 's/^# \{0,1\}//'; exit 0; }

# ----------------------------------------------------------------------------
# Parse args
# ----------------------------------------------------------------------------
while [ $# -gt 0 ]; do
    case "$1" in
        --with-chrome)         WITH_CHROME=1 ;;
        --with-client-config)  WITH_CLIENT_CONFIG=1 ;;   # default; kept for back-compat
        --no-client-config)    WITH_CLIENT_CONFIG=0 ;;
        --no-upload)           DO_UPLOAD=0 ;;
        -y|--yes)              ASSUME_YES=1 ;;
        -h|--help)             usage ;;
        *) err "unknown option: $1"; exit 2 ;;
    esac
    shift
done

# ----------------------------------------------------------------------------
# Pre-flight
# ----------------------------------------------------------------------------
command -v rsync >/dev/null 2>&1 || { err "rsync is required"; exit 1; }
command -v tar   >/dev/null 2>&1 || { err "tar is required"; exit 1; }
if [ "$DO_UPLOAD" -eq 1 ]; then
    command -v scp >/dev/null 2>&1 || { err "scp is required"; exit 1; }
    command -v ssh >/dev/null 2>&1 || { err "ssh is required"; exit 1; }
fi

info "project : $PROJECT_NAME v$VERSION"
info "source  : $PROJECT_ROOT"
info "package : $TARBALL"
if [ "$DO_UPLOAD" -eq 1 ]; then
    info "upload  : ${REMOTE_USER}@${REMOTE_HOST}:${REMOTE_PORT} -> ${REMOTE_DEST}/"
    info "url     : ${DOWNLOAD_URL}/${TARBALL}"
fi

# ----------------------------------------------------------------------------
# 1) Stage a clean copy
# ----------------------------------------------------------------------------
step "Staging clean tree"
STAGE="$(mktemp -d "${TMPDIR:-/tmp}/${PROJECT_NAME}.XXXXXX")"
trap 'rm -rf "$STAGE"' EXIT
DEST="$STAGE/$PROJECT_NAME"

RSYNC_EXCLUDES=(
    --exclude "var/"
    --exclude "dist/"
    --exclude "__pycache__/"
    --exclude "*.pyc"
    --exclude "*.pyo"
    --exclude "*~"
    --exclude ".idea/"
    --exclude ".git/"
    --exclude ".DS_Store"
    --exclude "*.log"
)
if [ "$WITH_CLIENT_CONFIG" -eq 0 ]; then
    RSYNC_EXCLUDES+=( --exclude "client_config.py" --exclude "client_config.pyc" )
    warn "excluding client_config.py (--no-client-config)."
else
    info "including client_config.py (per-terminal config will be shipped/overwritten on install)."
fi
if [ "$WITH_CHROME" -eq 0 ]; then
    RSYNC_EXCLUDES+=( --exclude "install/*.deb" )
    warn "skipping install/*.deb (~94MB). Use --with-chrome to include it."
fi

rsync -a "${RSYNC_EXCLUDES[@]}" "$PROJECT_ROOT/" "$DEST/"

# ----------------------------------------------------------------------------
# 2) Build the tarball  (top-level dir: premier-sbp-tools/ -> extracts to /)
# ----------------------------------------------------------------------------
step "Building tarball"
mkdir -p "$DIST_DIR"
# On macOS (bsdtar) strip Apple metadata/xattrs so GNU tar on the terminals
# doesn't spam "Ignoring unknown extended header keyword LIBARCHIVE.xattr...".
TAR_FLAGS=()
if tar --version 2>/dev/null | grep -qi 'bsdtar'; then
    TAR_FLAGS+=( --no-mac-metadata --no-xattrs )
fi
COPYFILE_DISABLE=1 tar "${TAR_FLAGS[@]}" -czf "$DIST_DIR/$TARBALL" -C "$STAGE" "$PROJECT_NAME"

SIZE="$(du -h "$DIST_DIR/$TARBALL" | cut -f1)"
if command -v shasum >/dev/null 2>&1; then
    SHA="$(shasum -a 256 "$DIST_DIR/$TARBALL" | cut -d' ' -f1)"
elif command -v sha256sum >/dev/null 2>&1; then
    SHA="$(sha256sum "$DIST_DIR/$TARBALL" | cut -d' ' -f1)"
else
    SHA="(no sha tool)"
fi
info "built  : dist/$TARBALL  ($SIZE)"
info "sha256 : $SHA"

# ----------------------------------------------------------------------------
# 3) Generate the installer that terminals run (curl + extract).
# ----------------------------------------------------------------------------
CURL_AUTH=""
[ -n "$DOWNLOAD_AUTH" ] && CURL_AUTH="-u $DOWNLOAD_AUTH "
cat > "$DIST_DIR/$INSTALLER" <<EOF
#!/usr/bin/env bash
# premier-sbp-tools installer — generated by build.sh (v${VERSION})
# Run on a terminal:  curl -fsSL ${CURL_AUTH}${DOWNLOAD_URL}/${INSTALLER} | sudo bash
set -e
URL="${DOWNLOAD_URL}/${TARBALL}"
TMP="\$(mktemp -d)"
echo "[install] downloading \$URL"
curl -fsSL ${CURL_AUTH}-o "\$TMP/${TARBALL}" "\$URL"
echo "[install] extracting into /"
SUDO=""; [ "\$(id -u)" -ne 0 ] && SUDO="sudo"
\$SUDO tar xzf "\$TMP/${TARBALL}" -C /              # -> /${PROJECT_NAME} (includes client_config.py)
\$SUDO find /${PROJECT_NAME} -name '*.pyc' -delete 2>/dev/null || true
\$SUDO find /${PROJECT_NAME} -name '__pycache__' -type d -prune -exec rm -rf {} + 2>/dev/null || true
rm -rf "\$TMP"
echo "[install] done. restart services with:"
echo "          \$SUDO manage-premier-sbp -a -t <atm|shop> -o <server_ip>"
EOF
chmod +x "$DIST_DIR/$INSTALLER"
info "installer: dist/$INSTALLER"

# --- Windows variant: same package, native curl.exe + tar.exe (Win10 1803+) ---
cp -f "$DIST_DIR/$TARBALL" "$DIST_DIR/$WIN_TARBALL"
cat > "$DIST_DIR/$WIN_INSTALLER" <<EOF
@echo off
REM premier-sbp-tools Windows installer — generated by build.sh (v${VERSION})
REM Run as Administrator. One-liner:
REM   curl -fsSL -o "%TEMP%\\sbp.cmd" ${DOWNLOAD_URL}/${WIN_INSTALLER} ^&^& "%TEMP%\\sbp.cmd"
setlocal
set "URL=${DOWNLOAD_URL}/${WIN_TARBALL}"
set "PKG=%TEMP%\\${WIN_TARBALL}"
echo [install] downloading %URL%
curl -fsSL ${CURL_AUTH}-o "%PKG%" "%URL%" || (echo download failed & exit /b 1)
echo [install] extracting into C:\\
tar -xf "%PKG%" -C C:\\ || (echo extract failed & exit /b 1)
del "%PKG%"
echo [install] done. restart services with:
echo          python C:\\premier-sbp-tools\\manage.py -a -t atm -o ^<server_ip^>
endlocal
EOF
# batch files want CRLF line endings
command -v perl >/dev/null 2>&1 && perl -i -pe 's/\n/\r\n/' "$DIST_DIR/$WIN_INSTALLER"
info "windows  : dist/$WIN_TARBALL + dist/$WIN_INSTALLER"

if [ "$DO_UPLOAD" -eq 0 ]; then
    info "build-only (--no-upload). Done."
    exit 0
fi

# ----------------------------------------------------------------------------
# 4) Confirm + upload into the admin home dir (no sudo needed)
# ----------------------------------------------------------------------------
if [ "$ASSUME_YES" -eq 0 ]; then
    printf "\nUpload to %s%s@%s:%s%s -> %s ? [y/N]: " \
        "$C_Y" "$REMOTE_USER" "$REMOTE_HOST" "$REMOTE_PORT" "$C_0" "$REMOTE_DEST"
    read -r reply
    case "$reply" in [yY]|[yY][eE][sS]) ;; *) warn "aborted by user."; exit 0 ;; esac
fi

step "Uploading"
SSH_OPTS="-p $REMOTE_PORT -o ConnectTimeout=15"
SCP_OPTS="-P $REMOTE_PORT -o ConnectTimeout=15"

ssh $SSH_OPTS "${REMOTE_USER}@${REMOTE_HOST}" "mkdir -p '$REMOTE_DEST'"
scp $SCP_OPTS \
    "$DIST_DIR/$TARBALL" "$DIST_DIR/$INSTALLER" \
    "$DIST_DIR/$WIN_TARBALL" "$DIST_DIR/$WIN_INSTALLER" \
    "${REMOTE_USER}@${REMOTE_HOST}:${REMOTE_DEST}/"
info "uploaded -> ${REMOTE_DEST}/ (linux + windows package & installer)"

# Best-effort reachability check (HEAD); non-fatal.
if command -v curl >/dev/null 2>&1; then
    if curl -fsI ${DOWNLOAD_AUTH:+-u "$DOWNLOAD_AUTH"} "${DOWNLOAD_URL}/${TARBALL}" >/dev/null 2>&1; then
        info "verified: ${DOWNLOAD_URL}/${TARBALL} is reachable"
    else
        warn "could not HEAD ${DOWNLOAD_URL}/${TARBALL}"
        warn "  -> check that ${REMOTE_DEST} is served at ${DOWNLOAD_URL} (set DOWNLOAD_URL if it uses a subpath)"
    fi
fi

cat <<EOF

${C_G}Uploaded.${C_0} Install on a terminal with EITHER:

  ${C_B}# one-liner (download + extract + .pyc cleanup):${C_0}
  curl -fsSL ${DOWNLOAD_AUTH:+-u $DOWNLOAD_AUTH }${DOWNLOAD_URL}/${INSTALLER} | sudo bash

  ${C_B}# or manual, with curl -O:${C_0}
  curl -O ${DOWNLOAD_AUTH:+-u $DOWNLOAD_AUTH }${DOWNLOAD_URL}/${TARBALL}
  sudo tar xzf ${TARBALL} -C /
  sudo manage-premier-sbp -a -t <atm|shop> -o <server_ip>

${C_G}Windows 10${C_0} (native curl.exe + tar.exe, build 1803+), run as Administrator:

  ${C_B}# one-liner (download installer + run):${C_0}
  curl -fsSL -o "%TEMP%\\sbp.cmd" ${DOWNLOAD_URL}/${WIN_INSTALLER} && "%TEMP%\\sbp.cmd"

  ${C_B}# or manual, with curl -O:${C_0}
  curl -O ${DOWNLOAD_URL}/${WIN_TARBALL}
  tar -xf ${WIN_TARBALL} -C C:\\
  python C:\\premier-sbp-tools\\manage.py -a -t atm -o <server_ip>

  ${C_B}# PowerShell pandan (curl|bash ekvivalent):${C_0}
  iwr ${DOWNLOAD_URL}/${WIN_INSTALLER} -OutFile \$env:TEMP\\sbp.cmd; & \$env:TEMP\\sbp.cmd
EOF
