
from uuid import getnode as get_mac

##################
# ACCEPTOR SETUP #
##################
BILL_PORT = '/dev/ttyS0'
BILL_PROTOCOL = 'id003'
COIN_PORT = '/dev/ttyS1'
COIN_PROTOCOL = 'cctalk'

################
# ACCESS SETUP #
################
ACCESS = {
	'user': '',
	'shop': '',
	'mac': get_mac(),
}

#################
# PRINTER SETUP #
#################
PRINTER_PORT = '/dev/usb/lp0'
IS_QR_CODE = True
USE_LOCAL_LOGO = False
if not USE_LOCAL_LOGO:
	IS_LOCAL_LOGO_TEXT = {'H1': 'SPORTSKE KLADIONICE', 'H2': 'PREMIER'}

#################
# SPLITTER SETUP #
#################



DISPLAY = {
	#'http://lucky6.premierbet.me': ['0000,0'],
	'https://kiosk.betroyal.casino': ['2000,0'],
	#'http://live.premierbet.me': ['2000,0'],
}

