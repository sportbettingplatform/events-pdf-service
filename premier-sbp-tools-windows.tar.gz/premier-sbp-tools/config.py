import os
import platform
import sys
from uuid import getnode as get_mac

#####################################################
################## COMMON SETUP #####################
#####################################################
BASE_DIR = os.path.abspath(os.path.dirname(__file__))
sys.path.append(BASE_DIR)
sys.path.insert(0, '../')

PY2 = sys.version_info[0] == 2
PY3 = sys.version_info[0] == 3

LINUX_PLATFORM = True if 'Linux' in platform.system() else False
WINDOWS_PLATFORM = True if 'Windows' in platform.system() else False

IS_SSL = True
DOMAIN = 'kiosk.betroyal.casino'
BASE_URI = '%s://%s' % ('http' if not IS_SSL else 'https', DOMAIN)

LOCAL_BASE_URI = 'https://%s' % DOMAIN
LOG_DIR = BASE_DIR + '/var/log/'
LOCK_DIR = BASE_DIR + '/var/lock/'
PID_DIR = BASE_DIR + '/var/pid/'
DB_DIR = BASE_DIR + '/var/db/'
if WINDOWS_PLATFORM:
	LOG_DIR = BASE_DIR + '\\var\\log\\'
	LOCK_DIR = BASE_DIR + '\\var\\lock\\'
	PID_DIR = BASE_DIR + '\\var\\pid\\'
	DB_DIR = BASE_DIR + '\\var\\db\\'

SECRET_COOKIE = 'd4nMSHnhiksVYwK7J7pjcpwVXxUhQJfgQCsQUBhc4Dq8Y2aodeiaxauvbV76TZe4wK6KuYPCq3JbTnkomc5mY5wt4PexNYFkZ2Ct5tGi22KtZSP3A4asAuoUhKYJmHL7'
SECRET_SALT = 'xauvbV76TZe4wK6KuYPCq3JbTnkom'

DEBUG = True
VERBOSE = DEBUG
#####################################################
################### MAIL SETUP ######################
#####################################################
SEND_GRID_API = "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"
ADMINISTRATORS = [
	# 'nemanja@premierbet.rs',
	'mirko@premierbet.rs',
	'petar@premierbet.rs',
]

#####################################################
################# CLIENT SETUP #####################
#####################################################
CLIENT_SERVICE_PORT = 2889
CLIENT_SERVICE_BACKDOOR_DEFAULT_PORT = 10000
ACCEPTOR_SET_PASSWORD_API = 'http://localhost:5565/acceptors/get/password'

#####################################################
############### SESSION / AUTH SETUP ################
#####################################################
# ATM session endpoints exposed by the backend users service
# (ATMClientServiceAPI). `create-session` returns a JWT for the ATM user;
# the JWT is exchanged for a session token that is sent back on every
# authenticated request as the `Auth-Token` header. The token is kept in
# memory by the acceptor and refreshed automatically on a 401 (expired session).
CREATE_SESSION_API = '/api/users/cli/atm/create-session'
SESSION_API = '/api/users/cli/atm/session'
SESSION_REQUEST_TIMEOUT = 30

#####################################################
################# PRINTER SETUP #####################
#####################################################
SAVE_TICKET_TO_LOG = True
PRINTER_SERVICE_PORT = 2888
PRINTER_FILE_LOCK = '%s%s' % (LOCK_DIR, 'reporter.lock')

#####################################################
############ BACKDOOR SETUP ###################
#####################################################
BACKDOOR_SERVER = 'registar@csp.premierbet.me'
BACKDOOR_SERVER_PORT = 8887
BACKDOOR_TUNNEL_PORT = 9999

#####################################################
################ REPORTER SETUP #####################
#####################################################
IVC_SPORTSBETTING_PRINTED_TICKETS_API = 'https://' + DOMAIN + '/report/printedTickets'
IVC_LUCKY6_PRINTED_TICKETS_API = 'https://' + DOMAIN + '/api/lucky6/ticket/printed-ivc'
IVC_TOMBOLA_PRINTED_TICKETS_API = 'https://' + DOMAIN + '/api/tombola/ticket/printed-ivc'
#####################################################
################ ISONIS SETUP #####################
#####################################################
REDIS_HOST_RDB_HOST = ''
REDIS_HOST_RDB_PORT = '8787'
REDIS_HOST_RDB_PASSWD = 'isonis'
REDIS_HOST_RDB_DB = 5

#####################################################
################ ACCEPTOR SETUP #####################
#####################################################
BAUD_RATE = 9600
TIMEOUT = 0.05
WRITE_TIMEOUT = 0.2
XONXOFF = True

TRANSACTION_API = '/api/transactions/acceptor/add'
PING_API = '/api/transactions/ping'
COIN_ACCEPTOR_ENCRYPTION_BIT = 8
COIN_ACCEPTOR_MAIN_LOOP_SLEEP = 0.30
COIN_ACCEPTOR_DESTINATION_ADDRESS = 128
COIN_ACCEPTOR_SOURCE_ADDRESS = 1

BILL_ACCEPTOR_ENCRYPTION_BIT = 16
BILL_ACCEPTOR_DESTINATION_ADDRESS = 40
BILL_ACCEPTOR_SOURCE_ADDRESS = 2
BILL_ACCEPTOR_MAIN_LOOP_SLEEP = 0.40
BILL_ACCEPTOR_SEC_KEY = '123456'
