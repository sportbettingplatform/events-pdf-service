#!/usr/bin/env python3

import random
import json
import pickle
import time
import config
import client_config
from utilities.database import redis_db
from utilities.extra import logger, doasync
from utilities.service import http_request

log = logger('ivc-lucky6-printed-tickets')

REPORTS_QUEUE = list()
IS_LOCKED = False

@doasync
def send_tickets():
	global IS_LOCKED
	global REPORTS_QUEUE

	BUFFER = list()
	while True:
		while REPORTS_QUEUE:
			IS_LOCKED = True
			item = REPORTS_QUEUE.pop()
			BUFFER.append(item)

		if BUFFER:
			http_request(method='POST', route=config.IVC_LUCKY6_PRINTED_TICKETS_API, payload={'codes': json.dumps(BUFFER)})
			BUFFER = list()
			IS_LOCKED = False
		time.sleep(random.randrange(3, 10))

		
if __name__ == '__main__':
	rdb = redis_db(decode_response=False)

	send_tickets()

	while True:
		if not IS_LOCKED:
			data = rdb.brpop('lucky6-printed-tickets', 1)
			
			if not data:
				continue
			
			payload = data[1]
			try:
				payload = payload.decode('utf-8')
			except:
				pass
			
			report = pickle.loads(payload)
			log.info('sending BUFFER: %s', report)
			REPORTS_QUEUE.append(report)
