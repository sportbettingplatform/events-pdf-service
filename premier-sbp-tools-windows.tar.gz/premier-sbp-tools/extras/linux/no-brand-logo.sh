#!/usr/bin/env bash

cd /premier-sbp-tools/extras/common/logo

mv logo.bmp old-logo.bmp
wget --user premier --password sbptools http://tools.premierbet.me/no-brand-logo.bmp
mv no-brand-logo.bmp logo.bmp

echo '[*] DONE! RESTART ATM'