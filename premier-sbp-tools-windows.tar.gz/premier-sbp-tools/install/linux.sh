#!/usr/bin/env bash

###############################################################
##################### CLIENT PARAMS ###########################
###############################################################

printf "###################################################################################\n"
printf "Environment setup. Please follow the instructions.\n"
read -p "Continue? (Y/N): " confirm && [[ $confirm == [yY] || $confirm == [yY][eE][sS] ]] || exit 1
read -p "Enter 'USERNAME' and press [ENTER]: " username
read -p "Enter 'SHOPNAME' and press [ENTER]: " shopname
read -p "Enter 'SERVER IP' and press [ENTER]: " server_ip
read -p "Enter 'BETTING TYPE' [atm|shop] and press [ENTER]: " device_type
read -p "Enter 'DISPLAY DRIVER' [Elo | CoolTouch ] and press [ENTER]: " display_driver
read -p "Generate new 'stunnel' certificate? [yes or no] and press [ENTER]': " install_stunnel
read -p "Enter 'COIN VALIDATOR PORT' and press [ENTER]: " coin
read -p "Enter 'BILL VALIDATOR PORT' and press [ENTER]: " bill
read -p "Enter 'PRINTER DEVICE PORT' and press [ENTER]: " printer

printf "\n"
read -p "Are you sure that you want to SAVE? (y/n): " confirm && [[ $confirm == [yY] || $confirm == [yY][eE][sS] ]] || exit 1

# wallpapper
gsettings set org.gnome.desktop.background picture-uri "file:///premier-sbp-tools/extras/common/wallpaper.jpg"

echo "
from uuid import getnode as get_mac

##################
# ACCEPTOR SETUP #
##################
BILL_PORT = '$bill'
BILL_PROTOCOL = 'cctalk'
COIN_PORT = '$coin'
COIN_PROTOCOL = 'cctalk'

################
# ACCESS SETUP #
################
ACCESS = {
	'user': '$username',
	'shop': '$shopname',
	'mac': get_mac(),
}

#################
# PRINTER SETUP #
#################
PRINTER_PORT = '$printer'
IS_QR_CODE = True
USE_LOCAL_LOGO = False
if not USE_LOCAL_LOGO:
	IS_LOCAL_LOGO_TEXT = {'H1': 'SPORTSKE KLADIONICE', 'H2': 'PREMIER'}

#################
# SPLITTER SETUP #
#################

" > ../client_config.py

if [[ $device_type == 'atm' ]]
  then
  echo "
DISPLAY = {
	'http://lucky6.premierbet.me': ['-1281,0'],
	'http://kiosk3.premierbet.me': ['0000,0'],
	'http://live.premierbet.me': ['2000,0'],
}
" >> ../client_config.py
fi

if [[ $device_type == 'shop' ]]
  then
  echo "
DISPLAY = {
	'http://reg.premierbet.me/#/shop/%s' % ACCESS['shop']: ['0000,0'],
}
" >> ../client_config.py
fi

###############################################################
################# PACKAGE INSTALLATION ########################
###############################################################

# install essential packages
apt-get -y update && apt-get -y dist-upgrade
apt-get -y autoremove
apt-get -y install python
apt-get -y -f install xinput-calibrator libxss1 python3-distutils libappindicator1 libindicator7 python-pip ntpdate net-tools libglib2.0-dev redis-server stunnel4 apt-transport-https lsb-release ca-certificates curl pkg-config libpcre3 libpcre3-dev needrestart libsqlite3-dev libffi-dev software-properties-common python-requests vim htop screen build-essential libpython3-dev openssh-server python-dev gcc

dpkg --configure -a

apt-get -y install python3-pip
apt-get -y install python-pip

pip3 install sendgrid redis tornado psutil colorlog msgpack colorama pyserial requests pillow reportlab
pip2 install pip -U
pip2 install sendgrid redis pyusb tornado psutil colorlog msgpack colorama pyserial requests pillow reportlab

# set executables
ln -sf /premier-sbp-tools/manage.py /usr/local/bin/manage-premier-sbp
echo 'export PYTHONPATH="/premier-sbp-tools:/premier-sbp-tools/services:${PYTHONPATH}"' >> ~/.bashrc
if [[ $device_type == 'atm' ]]
  then
  echo 'export PYTHONPATH="/premier-sbp-tools:/premier-sbp-tools/services:${PYTHONPATH}"' >> /home/atm/.bashrc
fi

if [[ $device_type == 'shop' ]]
  then
  echo 'export PYTHONPATH="/premier-sbp-tools:/premier-sbp-tools/services:${PYTHONPATH}"' >> /home/shop/.bashrc
fi

# install browser
wget https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb
dpkg -i google-chrome-stable_current_amd64.deb

###############################################################
################# CONTENT RESTRICTIONS ########################
###############################################################

echo "
# content-restriction
127.0.0.1 facebook.com
127.0.0.1 facebook.rs
127.0.0.1 facebook.me
127.0.0.1 instagram.com
127.0.0.1 instagram.rs
127.0.0.1 instagram.me
127.0.0.1 twitter.com
127.0.0.1 twitter.rs
127.0.0.1 twitter.me
" >> /etc/hosts

###############################################################
################# CRONTAB AND STARTUP #########################
###############################################################

mkdir -p /var/spool/cron/crontabs
echo "
# m h  dom mon dow   command
SHELL=/bin/bash
PATH=/usr/local/sbin:/usr/local/bin:/sbin:/bin:/usr/sbin:/usr/bin
PYTHONPATH=/premier-sbp-tools

@reboot manage-premier-sbp -a -t $device_type -o $server_ip
@reboot bash /premier-sbp-tools/scheduled-tasks/maintenance.sh
@reboot apt-get -y update && apt-get -y dist-upgrade
0 10 * * * /usr/sbin/ntpdate rs.pool.ntp.org
" > /var/spool/cron/crontabs/root
chmod 600 /var/spool/cron/crontabs/root

if [[ $device_type == 'atm' ]]
then
    mkdir /home/atm/.config/autostart/ -p
    chown atm.atm /home/atm/.config/autostart

    echo "
    [Desktop Entry]
    Type=Application
    Exec=python3 /premier-sbp-tools/services/splitter.py
    Hidden=false
    NoDisplay=false
    X-GNOME-Autostart-enabled=true
    Name[en_US]=display-splitter
    Name=display-splitter
    Comment[en_US]=
    Comment=
    " > /home/atm/.config/autostart/display-splitter.desktop

    echo "
    [Desktop Entry]
    Type=Application
    Exec=bash /premier-sbp-tools/extras/linux/display-drivers/xinput-startup.sh
    Hidden=false
    NoDisplay=false
    X-GNOME-Autostart-enabled=true
    Name[en_US]=xinput-startup
    Name=xinput-startup
    Comment[en_US]=
    Comment=
    " > /home/atm/.config/autostart/xinput-startup.desktop
fi

###############################################################
#################### STUNNEL SETUP ############################
###############################################################
echo "
[ req ]
default_bits                    = 2048
encrypt_key                     = no
distinguished_name              = req_dn
x509_extensions                 = cert_type

[ req_dn ]
countryName = Country Name (2 letter code)
countryName_default             = MN
countryName_min                 = 2
countryName_max                 = 2

stateOrProvinceName             = State or Province Name (full name)
stateOrProvinceName_default     = Montenegro

localityName                    = Locality Name (eg, city)
localityName_default            = Podgorica

organizationName                = Organization Name (eg, company)
organizationName_default        = Premier

organizationalUnitName          = Organizational Unit Name (eg, section)
#organizationalUnitName_default  = Provisional CA

0.commonName                    = Common Name (FQDN of your server)
0.commonName_default            = $username

[ cert_type ]
nsCertType                      = client
" > /etc/stunnel/stunnel.cnf

accept='5565'
connect='54565'
if [[ $server_ip == '127.0.0.1' ]]
    then
    accept='4565'
    connect='44565'
fi

echo "
cert = /etc/stunnel/stunnel.pem
key = /etc/stunnel/stunnel.pem
debug = 5
output = /var/log/stunnel.log
client = yes

[acceptors]
accept  = $accept
connect = $server_ip:$connect

[csp]
accept  = 8887
connect = 178.62.187.39:58887

" > /etc/stunnel/stunnel.conf

if  [[ $install_stunnel == [yY] || $install_stunnel == [yY][eE][sS] ]]
then
    manage-premier-sbp -i
    else

        echo "
-----BEGIN PRIVATE KEY-----
MIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQCymAzB92W2kAld
S1SL0H26SPmsWv7Zd0ebfXkXHM4Z73LhN0KwCtD3RdU0icfj+GTyTVP8Pg9nHbh8
n6KQuLZoA+EhmjDTEwPBmijrBawm2fvedIE2KJYDw07XOBJPFSdwTeP/+jMXTwfW
30h7YH/AfAc5/09GAE2twzpmzupTwQqvBxM4/1DBvTWtGPI8lbdzfAHGwpQ3HVfO
MSYCBoz9hwoD49FbF86rmEYImM0XzPJZnnTj/ko3ayHExP+UVNRZbgD8fzpBR5nx
3AfHRH5gActisAUhfJR8kqMEre5UnafvJPDFHo6Zes0bbl5BgvYSdn5lUoWArkb7
sytl6K11AgMBAAECggEAB/wIRfu7jmfuIz+k7gNKO7PbhbsjvbE5gFghu8jL5hjw
d+UylBBHu2Zh29F1IFoQmUyfvp0/rwqDHv88E2BOt2PFAu2T1Tv6ZQNxZOCCC9Kf
Ehj/Vd6GpnBq6/BT0TlO5BR3ZxBWjGo6HX8qDGoKDB7/a7ZgYu7MikI6MDJ8A3aA
zhZrElQw2iCasg2l3OkZJtmhkEF+QLXVlyX0f4MToSWfVZYhFqx19sfJP4Ghl3JH
IPnfbRE41KDw1JjwpEerLqHS7yEJjJJ0wfak83CzF+jke/1VzNTiSu1tfyJ882Ss
C0iy4CDQUs+A38JWqpiaIfyI8UWjBpJmwlxWKkJRGQKBgQDjTvkLF6oUofiB+JhZ
upuaDVoY5o9mU0dYTLn25iVDCvBzRspG1I5MtrCT2NzPHPz6L8YSX2Oy5XVrfNun
fEFReCndEAmzTcnB52l4Jc7N8OEc6V0//YhEZP1An6lJKBnc/O05Teq66lXr/EAU
R4i5AHv7t3S8mjRpdtPmKFZ9/wKBgQDJIvZXDJpUj3owajTDnuaJvqjGosW+vClT
H0yTztrl+Xf3cPVPZFOhehTzxvxgcPNkZSuz3ddpM2ZLYL7F5sVymjtw5wtl9WnO
kWbytANcJ3vdDbJfmX9PlZkxEVEs9dpXGD83exLvgFPpv6olMtVNy1LZizdnBoEW
l/+NW5W8iwKBgQDgEo113dIPnMs4dDLa4RVaeycBvOZHXHjMFnaLaLv6puH5ASON
RyMvhDf0xqaElHLcvhNnMRk61O83ElIFfHt3MBk0jgbB9kCZIOHbSonegUGoGnOO
DQMzSMpN1hYuw5UbP0kqYCCwOSiSBIu2cf3ZQRz3OhWdhfV8sWKZU9JPSQKBgQC1
h0Rk1A8FemiBAZmVY/gVIWoZvBZUSmXRi1IFpI+TN0+6lswPVzDTb+cxDMoCEG7a
kSScNP+RBr6wESScX+abw+8Zuqxi3Ncdg8UyDp1psojrvMzb0yE/pniX/FUTCuB/
8nY7kGxKk7soH79jyzkP+Q1RIYBjD0+6IHyYC6xceQKBgCJrf6rLZqN8E5pZZ9Gv
ZvrDePd7hVcP2jpxLJcA4Y49P1e2KNNRd9TzHl4OUiZmESo7vWtuktF7J9krYzZK
Pfe233U/9dxLLLxukp9hBvnWEGo9UZCXeVHOSAqnf6j1hli0D7+J0pJ1yyXqEqSy
kNFpGgNeymQ6ZMKw3U4CiLVy
-----END PRIVATE KEY-----
-----BEGIN CERTIFICATE-----
MIIDSjCCAjKgAwIBAgIJAKGag7Xr3CXgMA0GCSqGSIb3DQEBCwUAMFkxCzAJBgNV
BAYTAlNSMRAwDgYDVQQIDAdTUkJJQUpBMRIwEAYDVQQHDAlQb2Rnb3JpY2ExEDAO
BgNVBAoMB1ByZW1pZXIxEjAQBgNVBAMMCWxvY2FsaG9zdDAeFw0xODAxMTkxMDQ1
MTVaFw0yODAxMTcxMDQ1MTVaMFkxCzAJBgNVBAYTAlNSMRAwDgYDVQQIDAdTUkJJ
QUpBMRIwEAYDVQQHDAlQb2Rnb3JpY2ExEDAOBgNVBAoMB1ByZW1pZXIxEjAQBgNV
BAMMCWxvY2FsaG9zdDCCASIwDQYJKoZIhvcNAQEBBQADggEPADCCAQoCggEBALKY
DMH3ZbaQCV1LVIvQfbpI+axa/tl3R5t9eRcczhnvcuE3QrAK0PdF1TSJx+P4ZPJN
U/w+D2cduHyfopC4tmgD4SGaMNMTA8GaKOsFrCbZ+950gTYolgPDTtc4Ek8VJ3BN
4//6MxdPB9bfSHtgf8B8Bzn/T0YATa3DOmbO6lPBCq8HEzj/UMG9Na0Y8jyVt3N8
AcbClDcdV84xJgIGjP2HCgPj0VsXzquYRgiYzRfM8lmedOP+SjdrIcTE/5RU1Flu
APx/OkFHmfHcB8dEfmABy2KwBSF8lHySowSt7lSdp+8k8MUejpl6zRtuXkGC9hJ2
fmVShYCuRvuzK2XorXUCAwEAAaMVMBMwEQYJYIZIAYb4QgEBBAQDAgeAMA0GCSqG
SIb3DQEBCwUAA4IBAQAa7UKDw9FeKFRLXqxUs8tJ9Ig1H2Jzzoz+f/biryiMdxt/
oTlL4xsogEfTIZqa8QpvJRFdaz7rKoF3fcgRGpQIJc9Vy0N+W0xUbaHW9eax+cyP
tSauhnUiFEkm47YgTUDhk0TTs1+6Hj1yN3ePdaDT98Qh7V2yiH+ofF6QNrZZNWKh
Q/PfM1SgE08ibzRvbYm/1e4ZlWgnuXV5M4dpJvQGaDarGDG92bjPxjJo0rxmP8Z+
qHRJnwxPPASoGQU3K5GXWD+Ap9nI2Ma9NwQaztkRmHIOwmehp6VrnoVAI2VZSqx7
iDDm0jCPsGEP8NDFxHrpoey9CBUa/vmezp3KaSyd
-----END CERTIFICATE-----
" > /etc/stunnel/stunnel.pem
fi
chmod 600 /etc/stunnel/stunnel.pem

###############################################################
#################### DISABLE MOUSE ############################
###############################################################
echo "xserver-command=X -core -nocursor" > /usr/share/lightdm/lightdm.conf.d/50-xserver-command.conf

###############################################################
################# DISPLAY DRIVER SETUP ########################
###############################################################
if [[ $display_driver != '' ]]
    then

    # calibration
    touch_output_id=$(xinput list|grep ${display_driver} |grep id=|cut -f 2|cut -f 2 -d =)
    primary_output_port=$(xrandr|grep '\sconnected'|grep primary| cut -f 1|cut -f 3 -d =|cut -d " " -f1)

    # turnoff secondary non-touch display
    secondary_output_port=$(xrandr|grep '\sconnected'|grep -v primary| tr -d '\r\n'|cut -d " " -f1)
    xrandr --output  $secondary_output_port  --off

    # map primary touch screen
    xinput map-to-output $touch_output_id $primary_output_port

    # start calibration and save config
    xinput_calibrator --misclick 0  --output-filename /usr/share/X11/xorg.conf.d/99-calibration.conf

    # create startup script
    echo "
    #!/usr/bin/env bash

    touch_output_id=$(xinput list|grep ${display_driver} |grep id=|cut -f 2|cut -f 2 -d =)
    primary_output_port=$(xrandr|grep '\sconnected'|grep primary| cut -f 1|cut -f 3 -d =|cut -d " " -f1)

    # map primary touch screen
    xinput map-to-output $touch_output_id $primary_output_port

    " > /premier-sbp-tools/extras/linux/display-drivers/xinput-startup.sh

    chmod 755 /premier-sbp-tools/extras/linux/display-drivers/xinput-startup.sh
    chmod 755 /premier-sbp-tools/services/splitter.py

fi

###############################################################
###################### FIREWALL ###############################
###############################################################
# default
iptables -P INPUT DROP
iptables -P FORWARD DROP
iptables -P OUTPUT ACCEPT

# localhost
iptables -A INPUT -i lo -j ACCEPT

# ako je konekcija zapoceta iznutra, pusti je
iptables -A INPUT -m state --state ESTABLISHED,RELATED -j ACCEPT

ssh-keygen -t rsa -b 4096

printf "###################################################################################\n"
printf "\n\nCopy SSH key to CSP server.\n\n"
printf "###################################################################################\n"

cat /root/.ssh/id_rsa.pub

printf "###################################################################################\n"
printf "\n\nSetup is complete. Please restart.\n\n"
printf "###################################################################################\n"

