#!/usr/bin/env python3

import subprocess
import argparse
import random
import os
import sys
import time
import requests
import config
import client_config
from utilities.extra import kill_all, start_process
from utilities.service import http_request
from utilities.string import green, red, yellow
sys.path.insert(0, '../')


def kill_by(name):
	import psutil
	killed = []
	for proc in psutil.process_iter():
		if proc.name() == name and proc.pid != os.getpid():
			proc.kill()
			killed.append(proc.pid)
	if not killed:
		sys.exit('%s: no process found' % name)
	else:
		sys.exit(0)


def pid_of(pgname):
	import psutil
	pids = []
	for proc in psutil.process_iter():
		with proc.oneshot():
			# search for matches in the process name and cmdline
			try:
				name = proc.name()
			except psutil.Error:
				pass
			else:
				if name == pgname:
					pids.append(str(proc.pid))
					continue
			
			try:
				cmdline = proc.cmdline()
			except psutil.Error:
				pass
			else:
				if cmdline and cmdline[0] == pgname:
					pids.append(str(proc.pid))
	return pids


def all_start():

	if not os.path.isdir(config.BASE_DIR + '/var'):
		os.mkdir(config.BASE_DIR + '/var')
		
	if not os.path.isdir(config.LOCK_DIR):
		os.mkdir(config.LOCK_DIR)
	
	# check if var folder exists
	if not os.path.isdir(config.LOG_DIR):
		os.mkdir(config.LOG_DIR)

	# check if var folder exists
	if not os.path.isdir(config.PID_DIR):
		os.mkdir(config.PID_DIR)
	
	# check if pid file exists
	if not os.path.isfile(config.PID_DIR + 'app.pids'):
		open(config.PID_DIR + 'app.pids', 'w+')
	
	# start redis server
	if config.LINUX_PLATFORM:
		os.system('redis-server >/dev/null 2>&1 & ')
	elif config.WINDOWS_PLATFORM:
		pass
	
	time.sleep(.5)
	
	# ######################################
	# ** kill all running process
	# ######################################
	kill_all()
	# ######################################
	# ** list of all processes to be started
	# ######################################
	
	if args.type in ['atm']:
		link_stunnel()
		if config.LINUX_PLATFORM:
			start_process(["python3", config.BASE_DIR + "/services/printer.py", "--printer=" + client_config.PRINTER_PORT], 0.2)
		start_process(["python3", config.BASE_DIR + "/services/backdoor-client.py"], 1)
		start_process(["python2", config.BASE_DIR + "/services/acceptor.py", "-t", "coin", "-p", client_config.COIN_PORT, "-o", client_config.COIN_PROTOCOL], 5)
		start_process(["python2", config.BASE_DIR + "/services/acceptor.py", "-t", "bill", "-p", client_config.BILL_PORT, "-o", client_config.BILL_PROTOCOL], 0.2)
		start_process(["python3", config.BASE_DIR + "/daemons/backdoor-client-polling.py"], 0.2)
		start_process(["python3", config.BASE_DIR + "/daemons/ivc-sportsbetting-printed-tickets.py"], 0.2)
		# start_process(["python3", config.BASE_DIR + "/daemons/ivc-lucky6-printed-tickets.py"], 0.2)
		# start_process(["python3", config.BASE_DIR + "/daemons/ivc-tombola-printed-tickets.py"], 0.2)
		start_process(["python3", config.BASE_DIR + "/services/splitter.py"], 0.2)

	if args.type in ['shop']:
		link_stunnel()
		start_process(["python3", config.BASE_DIR + "/services/printer.py", "--printer=" + client_config.PRINTER_PORT], 0.2)
		start_process(["python3", config.BASE_DIR + "/services/backdoor-client.py"], 0.2)
		start_process(["python3", config.BASE_DIR + "/daemons/ivc-sportsbetting-printed-tickets.py"], 0.2)
		start_process(["python3", config.BASE_DIR + "/daemons/ivc-lucky6-printed-tickets.py"], 0.2)
		start_process(["python3", config.BASE_DIR + "/daemons/ivc-tombola-printed-tickets.py"], 0.2)
		start_process(["python3", config.BASE_DIR + "/daemons/backdoor-client-polling.py"], 0.2)

	if args.type in ['backdoor-server']:
		start_process(["python3", config.BASE_DIR + "/services/backdoor-server.py"], 0.2)

	if args.type in ['dev']:
		link_stunnel()
		start_process(["python3", config.BASE_DIR + "/services/printer.py", "--printer=" + client_config.PRINTER_PORT], 0.2)
		start_process(["python3", config.BASE_DIR + "/services/backdoor-server.py"], 0.2)
		start_process(["python3", config.BASE_DIR + "/services/backdoor-client.py"], 0.2)
		start_process(["python3", config.BASE_DIR + "/daemons/backdoor-client-polling.py"], 0.2)
	
	if config.LINUX_PLATFORM:
		start_process(["stunnel4"], 0.2)


def install():

	if config.LINUX_PLATFORM:
		link_stunnel()

	elif config.WINDOWS_PLATFORM:
		pass


def link_stunnel():
	if config.LINUX_PLATFORM:
		with open('/etc/stunnel/stunnel.conf', 'w') as f:
			f.write('''
cert = /etc/stunnel/stunnel.pem
key = /etc/stunnel/stunnel.pem
debug = 5
output = /var/log/stunnel.log
client = yes

[acceptors]
accept  = %s
connect = %s:%s

[backdoor]
accept  = 8887
connect = 178.62.187.39:58887

	''' % ('4565' if args.host == '127.0.0.1' else '5565', args.host, '44565' if args.host == '127.0.0.1' else '54565'))
	elif config.WINDOWS_PLATFORM:
		pass


def update():

	if config.LINUX_PLATFORM:
		try:
			os.remove('rm -rf /home/atm/premier-sbp-tools-linux.*')
		except:
			pass
		os.system('curl -u premier:sbptools http://tools.premierbet.me/premier-sbp-tools-linux.sh | bash')

	elif config.WINDOWS_PLATFORM:
		# todo, need testing
		os.system('''
			@echo off
			cd C:
			URL2File http://%s/premier-sbp-tools-windows.zip premier-sbp-tools-windows.zip 
			pkunzip premier-sbp-tools-windows.zip
		''' % (config.DOMAIN,))


def remote_connection():
	
	if not args.client_username:
		sys.exit('\nEnter remote client username\n')
	
	if not args.client_port:
		args.client_port = random.randrange(10000, 40000)
		
	available_commands = {
		1 : 'open_tunnel',
		2 : 'restart-sbp-tools',
		3 : 'shutdown',
		4 : 'restart',
		5 : 'teamviewer',
		6 : 'update',
		7 : 'kill_chrome',
		8 : 'display_on',
		9 : 'display_off'
	}
	
	print(yellow("""
	Commands:
		1. open_tunnel                  - open communication tunnel
		2. restart-sbp-tools            - restart-sbp-tools
		3. shutdown                     - power-off remote client
		4. restart                      - restart remote client
		5. teamviewer                   - start team-viewer
		6. update                       - update premier-sbp-tools package
		7. kill_chrome                  - kill all google-chrome instances
		8. display_on                   - display on
		9. display_off                  - display off
	"""))
	
	print('\n Hint: To send command to all connected clients, enter __all__ for -c argument\n')
	
	command = int(input(green('CHOOSE COMMAND OPTION?\n> ')))
	if not command or command == '' or command not in available_commands:
		command = 1
	
	username, host = args.client_username.split('@')
	connection = http_request(method='post', route='http://csp.%s.me:%s/send' % (config.DOMAIN, config.BACKDOOR_SERVER_PORT), payload={
		'id_client': username,
		'command'  : available_commands[command],
		'port'     : args.client_port
	})
	
	if connection.status_code == 200:
		if available_commands[command] == 'open_tunnel':
			if username != '__all__':
				print(green('\nconnecting to %s:%s ...\n' % (args.client_username, args.client_port)))
				while True:
					os.system('ssh %s@localhost -p %s' % (host, args.client_port))
					time.sleep(2)
				
		else:
			print(green('\ncommand [%s] is successfully executed on %s\n' % (available_commands[command], args.client_username)))
	else:
		sys.exit(red('Connection failed, try again!'))


if __name__ == '__main__':
	
	parser = argparse.ArgumentParser(description=green("PREMIER-SBP TOOLS"), formatter_class=lambda prog: argparse.HelpFormatter(prog, max_help_position=100, width=300))
	parser.add_argument("-a", "--all", dest="all_start", help='start all services. %s' % (red('Example: `manage.py -a`')), required=False, default=False, action='store_true')
	parser.add_argument("-i", "--install", dest="install", help='install all packages.', required=False, default=False, action='store_true')
	parser.add_argument("-t", "--type", dest="type", help='type', required=False, default=False, choices=['dev', 'atm', 'shop', 'backdoor-server', 'remote'])
	parser.add_argument("-o", "--host", dest="host", help='host', required=False, default='127.0.0.1')
	parser.add_argument("-u", "--update", dest="update", help='update', required=False, action='store_true')
	parser.add_argument("-c", "--client_username", dest="client_username", help='remote client username. Example: manage-premier-sbp -t remote -c atm_test@[atm | registar]', required=False)
	parser.add_argument("-p", "--client_port", dest="client_port", help='remote client (forced) port', required=False)

	try:
		args = parser.parse_args()
	
		if args.install:
			install()
		elif args.all_start:
			all_start()
		elif args.update:
			update()
		elif args.type in ['remote']:
			remote_connection()
		else:
			parser.print_help()
	except Exception as e:
		sys.exit()
