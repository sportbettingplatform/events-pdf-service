#!/usr/bin/env bash

find /premier-sbp-tools/var/log/ -mtime +45 -type f -delete

find /premier-sbp-tools/var/db/ -mtime +45 -type f -delete