#!/usr/bin/env python3

import json
import time
import os
import platform
import signal
import socket
import threading

import psutil
import requests
import tornado.httpclient
import tornado.httpserver
import tornado.ioloop
import tornado.web

import config
import client_config
from utilities.extra import logger, start_process
from utilities.number import bytes2human
from utilities.service import http_request, status_error, status_ok
from utilities.string import green, red


# Lista origina kojima je dozvoljeno da zovu servis.
# Najbolje je drzati ovo u config.py, npr:
#   ALLOWED_ORIGINS = ['https://s1-kiosk.premierbet.me']
# Ako za sada zelis sve da dozvolis, ostavi ['*'] (NE preporucuje se za /getUser
# jer taj endpoint vraca lozinku - vidi napomenu ispod).
ALLOWED_ORIGINS = getattr(config, 'ALLOWED_ORIGINS', ['*'])

log = logger('client-service')


# ----------------------------------------------------------------------------
# In-memory backend session (shared across requests in this process).
# Same pattern as services/acceptor.py: authenticate the terminal, send the
# session token as the `Auth-Token` header, and re-authenticate automatically
# on a 401 (expired session).
# ----------------------------------------------------------------------------
_SESSION = {'token': None}
_SESSION_LOCK = threading.Lock()


def create_session():
	"""Authenticate this terminal against the backend and cache the session
	token in memory. Returns True on success, False otherwise.

	Mirrors the kiosk login: POST create-session -> JWT, then
	GET session?token=<jwt> -> session token used as the `Auth-Token` header.
	"""
	username = client_config.ACCESS['user']
	try:
		created = requests.request(
			method='POST',
			url=config.LOCAL_BASE_URI + config.CREATE_SESSION_API,
			json={'username': username},
			timeout=config.SESSION_REQUEST_TIMEOUT,
		)
		if created.status_code != 200:
			log.error('[session] create-session failed for %s: HTTP %s', username, created.status_code)
			return False

		jwt_token = (created.json() or {}).get('data')
		if not jwt_token:
			log.error('[session] create-session returned no token for %s', username)
			return False

		exchanged = requests.request(
			method='GET',
			url=config.LOCAL_BASE_URI + config.SESSION_API,
			params={'token': jwt_token},
			timeout=config.SESSION_REQUEST_TIMEOUT,
		)
		if exchanged.status_code != 200:
			log.error('[session] session exchange failed for %s: HTTP %s', username, exchanged.status_code)
			return False

		data = (exchanged.json() or {}).get('data') or {}
		token = data.get('token')
		if not token:
			log.error('[session] session exchange returned no session token for %s', username)
			return False

		with _SESSION_LOCK:
			_SESSION['token'] = token
		log.info('[session] %s authenticated; token cached in memory', username)
		return True
	except Exception as e:
		log.error('[session] authentication error for %s: %s', username, e)
		return False


def get_token():
	with _SESSION_LOCK:
		return _SESSION['token']


def clear_token():
	with _SESSION_LOCK:
		_SESSION['token'] = None


def ensure_session():
	"""Make sure a session token is available, creating one if needed."""
	if get_token():
		return True
	return create_session()


def session_request(method='post', url='/', data=None):
	"""Authenticated backend request: sends `data` as a JSON body and the cached
	session token as the `Auth-Token` header. On a 401 (expired/missing session)
	it re-creates the session once, keeps the new token in memory, and retries.
	Returns the parsed JSON on a 2xx response, otherwise None.
	"""
	ensure_session()

	response = None
	for attempt in (1, 2):
		try:
			response = requests.request(
				method=method,
				url=config.LOCAL_BASE_URI + url,
				json=data,
				headers={'Auth-Token': get_token() or ''},
				timeout=config.SESSION_REQUEST_TIMEOUT,
			)
		except Exception as e:
			log.error('[session] request to %s failed: %s', url, e)
			return None

		if response.status_code == 401 and attempt == 1:
			log.warning('[session] 401 received - session expired, re-authenticating')
			clear_token()
			if not create_session():
				return None
			continue
		break

	if not (200 <= response.status_code < 300):
		log.error('[session] server returned HTTP %s for %s', response.status_code, url)
		return None

	try:
		return response.json()
	except Exception as e:
		log.error('[session] invalid JSON response from %s: %s', url, e)
		return None


class CorsBaseHandler(tornado.web.RequestHandler):
	"""
	Bazni handler koji svim odgovorima dodaje CORS zaglavlja i obradjuje
	CORS preflight (OPTIONS) zahtev. Bez obrade OPTIONS-a, XHR sa drugog
	origina (https://s1-kiosk.premierbet.me -> https://localhost:2889)
	pada na 'access control checks'.
	"""

	def set_default_headers(self):
		origin = self.request.headers.get('Origin')

		if '*' in ALLOWED_ORIGINS:
			# Refleksija origina (umesto bukvalnog '*') je obavezna ako ikada
			# budes slao kolacice / Authorization, jer '*' + credentials ne radi.
			self.set_header('Access-Control-Allow-Origin', origin or '*')
		elif origin in ALLOWED_ORIGINS:
			self.set_header('Access-Control-Allow-Origin', origin)

		self.set_header('Vary', 'Origin')
		self.set_header('Access-Control-Allow-Methods', 'GET, POST, OPTIONS')
		self.set_header('Access-Control-Allow-Headers', 'Content-Type, Authorization, X-Requested-With')
		self.set_header('Access-Control-Allow-Credentials', 'true')
		self.set_header('Access-Control-Max-Age', '86400')

	def options(self, *args, **kwargs):
		# Preflight - vrati prazan 204, zaglavlja vec postavlja set_default_headers.
		self.set_status(204)
		self.finish()


class MainHandler(CorsBaseHandler):

	def get(self):
		self.write("PremierSBP - client service")


class HostStatsHandler(CorsBaseHandler):

	def get(self):

		try:
			# Trik da saznamo lokalnu (LAN) IP adresu ove masine.
			s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
			s.connect(("8.8.8.8", 80))
			ip_address = s.getsockname()[0]
		except Exception:
			ip_address = '127.0.0.1'

		try:
			pipe = os.popen("cat /proc/cpuinfo |" + "grep 'model name'")
			data = pipe.read().strip().split(':')[-1]
			pipe.close()
			if not data:
				pipe = os.popen("cat /proc/cpuinfo |" + "grep 'Processor'")
				data = pipe.read().strip().split(':')[-1]
				pipe.close()
			cpu_type = data
		except Exception:
			cpu_type = '*'

		self.write(status_ok(msg={
			'hostname': socket.gethostname(),
			'ip'      : ip_address,
			'platform': platform.platform(),
			'cpu_info': '{} / {} core(s)'.format(cpu_type.strip(), psutil.cpu_count()),
			'mem_info': bytes2human(psutil.virtual_memory().total)
		}))


class CommandHandler(CorsBaseHandler):

	def parse_arguments(self):
		response = {}
		for arg in self.request.arguments:
			try:
				response[arg] = self.request.arguments[arg][0].decode('utf-8')
			except Exception:
				response[arg] = self.request.arguments[arg][0]
		return response

	def get(self):

		args = self.parse_arguments()

		cmd = args.get('command')
		backdoor_port = args.get('port', config.CLIENT_SERVICE_BACKDOOR_DEFAULT_PORT)

		if not cmd:
			return self.write(status_error('missing argument'))

		try:
			log.info(cmd)
			if cmd == 'shutdown':
				if config.LINUX_PLATFORM:
					os.system('/sbin/halt')
				elif config.WINDOWS_PLATFORM:
					os.system('shutdown /s /t 0')

			elif cmd == 'restart':
				if config.LINUX_PLATFORM:
					os.system('/sbin/reboot')
				elif config.WINDOWS_PLATFORM:
					os.system('shutdown /r /t 0')

			elif cmd == 'restart-sbp-tools':
				if config.LINUX_PLATFORM:
					os.system('manage-premier-sbp -a')
				elif config.WINDOWS_PLATFORM:
					os.system('python3.exe C:\\premier-sbp-tools\\manage.py -a -t terminal -o %s' % client_config.SERVER_IP)

			elif cmd == 'teamviewer':
				if config.LINUX_PLATFORM:
					os.system('DISPLAY=:0 teamviewer &')
				elif config.WINDOWS_PLATFORM:
					os.system('teamviewer.exe')

			elif cmd == 'open_tunnel':
				if len(str(backdoor_port)) != 5:
					self.write(status_error('Invalid port {} try: 10000 - 45000'.format(backdoor_port)))

				if config.LINUX_PLATFORM:
					log.info('Opening tunnel on port: {}'.format(backdoor_port))
					os.system('ssh -o "StrictHostKeyChecking no" -f -N -R %s:localhost:22 %s -p %s' % (backdoor_port, config.BACKDOOR_SERVER, config.BACKDOOR_TUNNEL_PORT))
				elif config.WINDOWS_PLATFORM:
					pass

			elif cmd == 'update':
				if config.LINUX_PLATFORM:
					os.system('manage-premier-sbp -u')
				elif config.WINDOWS_PLATFORM:
					os.system('python3 C:\\premier-sbp-tools\\manage.py -u ')

			elif cmd == 'kill_chrome':
				if config.LINUX_PLATFORM:
					os.system('killall chrome')
					time.sleep(1)
					start_process(["python3", config.BASE_DIR + "/services/splitter.py"], 0.2)
				elif config.WINDOWS_PLATFORM:
					os.system('TASKKILL /IM chrome.exe /F')

			elif cmd == 'display_on':
				if config.LINUX_PLATFORM:
					os.system('systemctl set-default graphical.target')
					os.system('init 5')
				elif config.WINDOWS_PLATFORM:
					pass

			elif cmd == 'display_off':
				if config.LINUX_PLATFORM:
					os.system('init 3')
					os.system('systemctl set-default multi-user.target')
				elif config.WINDOWS_PLATFORM:
					pass

		except Exception as e:
			log.error('Error executing command {}:\n{}'.format(cmd, e))
			return self.write(status_error('Error executing command {}:\n{}'.format(cmd, e)))

		self.write(status_ok('success', **{
			'cmd_status': 'executed',
			'cmd': cmd,
		}))
		self.finish()


class GetTunnelPortHandler(CorsBaseHandler):

	def get(self):
		self.write(status_ok('success', port=config.CLIENT_SERVICE_BACKDOOR_DEFAULT_PORT))


class GetUserHandler(CorsBaseHandler):

	def get(self):
		# New backend: the terminal authenticates with a session token
		# (Auth-Token), not a static password. (Re)authenticate and hand the
		# kiosk the username + session token; the token is kept in memory and
		# refreshed automatically on a 401.
		if not create_session():
			return self.write(status_error('could not establish backend session'))

		log.info('successfully logged %s', client_config.ACCESS['user'])
		return self.write(status_ok('success', **{
			'username': client_config.ACCESS['user'],
			'token'   : get_token(),
		}))


application = tornado.web.Application([
	(r"/", MainHandler),
	(r"/command", CommandHandler),
	(r"/getUser", GetUserHandler),
	(r"/getPort", GetTunnelPortHandler),
	(r"/host", HostStatsHandler)

], cookie_secret=config.SECRET_COOKIE, debug=True)

if __name__ == "__main__":

	log = logger('client-service')

	print(green("[*] PremierSBP client service started on {}".format(config.CLIENT_SERVICE_PORT)))
	log.info("PremierSBP client service started on {}".format(config.CLIENT_SERVICE_PORT))

	# establish the backend session on startup (kept in memory, refreshed on 401)
	if create_session():
		log.info('[session] backend session established for %s', client_config.ACCESS['user'])
	else:
		log.warning('[session] no backend session on startup; will retry on first request')

	try:
		# if config.IS_SSL:
		# 	app = tornado.httpserver.HTTPServer(application, ssl_options={
		# 		"certfile": "/etc/sbp/sbp.crt",
		# 		"keyfile" : "/etc/sbp/sbp.key"
		# 	})
		# else:
		app = tornado.httpserver.HTTPServer(application)

		def signal_handler(sig, frame):
			def _shutdown(server):
				log.info('Stopping server')
				server.stop()
				log.info('Shutting down')
				tornado.ioloop.IOLoop.instance().stop()
				log.info('Shut down')

			tornado.ioloop.IOLoop.instance().add_callback_from_signal(_shutdown, app)

		signal.signal(signal.SIGINT, signal_handler)
		signal.signal(signal.SIGTERM, signal_handler)

		app.listen(config.CLIENT_SERVICE_PORT)
		tornado.ioloop.IOLoop.current().start()

	except Exception as e:
		print(red(e))
		log.critical(e)