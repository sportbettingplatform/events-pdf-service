import sys, os
from serial import SerialException

if sys.executable.endswith("python2w.exe"):
	sys.stdout = open(os.devnull, "w")
	sys.stderr = open(os.path.join(os.getenv("TEMP"), "stderr-" + os.path.basename(sys.argv[0])), "w")

import serial.tools.list_ports
import serial
import hashlib
import redis
import signal
import socket
import json
import datetime
import sqlite3
import requests
import argparse
import config
import client_config
import time
import threading
from struct import unpack, pack
import constants.cctalk_headers as cctalk_headers
import constants.id003_headers as id003_headers
import constants.money_slots

from utilities.connectors import Serial
from utilities.extra import doasync, serial_ports, logger, lock_acceptor, send_mail
from utilities.string import green, red, yellow

BILL_RESPONSE_QUEUE = None
COIN_RESPONSE_QUEUE = None

# ----------------------------------------------------------------------------
# In-memory ATM session, shared across acceptor threads in this process.
# The backend authenticates the ATM from its session token (sent as the
# `Auth-Token` header). The token is created when the acceptor starts and
# refreshed automatically on any 401 (expired session).
# ----------------------------------------------------------------------------
_SESSION = {'token': None}
_SESSION_LOCK = threading.Lock()


##########################
# ID003 PROTOCOL
##########################
class ID003payload(object):

	def __init__(self, header, data=''):
		self.header = header
		self.data = data

	def __repr__(self):
		return chr(self.header) + self.data


class ID003Message(object):
	def __init__(self, header=0, data=''):
		self.header = chr(header)  # 1 byte
		self.lng = '\x00'  # 1 byte
		self.sync = '\xfc'  # 1 byte fixed start code
		self.data = data  # 0 - 250 bytes
		self.crc = '\x00'  # 2 bytes calucated

		self.payload = ID003payload(header, data)
		self.lng = self._calculate_lng()
		self.crc = self._calculate_crc()

	def _calculate_lng(self):
		# 1-sync + 1-lng + 1-cmd + 2-crc
		return chr(len(self.data) + 1 + 1 + 1 + 2)

	def raw(self):
		"""
		Returns a byte string representing the ccTalk message
		"""
		return self.sync + self.lng + self.header + self.data + self.crc if self.data else self.sync + self.lng + self.header + self.crc

	def __eq__(self, other):
		return self.lng == other.lng and self.header == other.cmd and self.data == other.data and self.crc == other.crc

	def __nonzero__(self):
		return not (self.header == '\x00' and self.lng == '\x00' and self.data == '' and self.crc == '\x00' and self.response == '')

	def check_response(self, response):
		self.lng = response[1]
		self.header = response[2]
		lng = int(response[1].encode('hex'), 16)
		datalng = lng - (1 + 1 + 1 + 2)  # 1-sync + 1-lng + 1-cmd + 2-crc
		self.data = response[3:3 + datalng]
		crc = response[-2:]

		if not self._check_crc(crc):
			return False
		return True

	def _check_crc(self, crc_to_check):
		self.crc = self._calculate_crc()
		return self.crc == crc_to_check

	def _calculate_crc(self):
		crcdata = self.sync + self.lng + self.header + self.data
		crcval = 0
		crcdata = unpack('={}c'.format(len(crcdata)), crcdata)

		for l in crcdata:
			c = int(l.encode('hex'), 16) & 0xFF
			q = (crcval ^ c) & 0x0F
			crcval = (crcval >> 4) ^ (q * 0x1081)
			q = (crcval ^ (c >> 4)) & 0x0F
			crcval = (crcval >> 4) ^ (q * 0x1081)
		return pack('=H', crcval)

##########################
# CCTALK PROTOCOL
##########################

class CCTalkPayload(object):

	def __init__(self, header, data=''):
		self.header = header
		self.data = data

	def __repr__(self):
		return chr(self.header) + self.data


class CCTalkMessage(object):
	def __init__(self, data='', source=999, destination=999, header=0, payload='', encryption_bit=None):

		self.data = data
		self.header = header
		self.header_humanize = cctalk_headers.N2K[header]
		self.encryption_bit = encryption_bit

		if self.data == '':
			# Creates a blank message
			self.destination = destination
			self.length = len(payload)
			self.source = source
			self.payload = CCTalkPayload(header,  payload)

		elif self._verify_crc_8(self.data):
			# Generates a message using raw data (Checksum)
			self.destination = ord(self.data[0])
			self.length = ord(self.data[1])
			self.source = ord(self.data[2])
			header = ord(self.data[3])
			self.data = self.data[4:-1]
			self.payload = CCTalkPayload(header,  self.data)

		elif self._verify_crc_16(self.data):
			# Generates a message using raw data (CRC)
			self.destination = ord(self.data[0])
			self.length = ord(self.data[1])
			self.source = 1  # Source is always assumed to be 1 in CRC mode
			header = ord(self.data[3])
			self.data = self.data[4:-1]
			self.payload = CCTalkPayload(header,  self.data)

		else:
			raise Exception

	def raw(self):
		"""
		Returns a byte string representing the ccTalk message
		"""
		# unencrypted
		if self.encryption_bit == 8:
			return chr(self.destination) + chr(self.length) + chr(self.source) + repr(self.payload) + chr( self._crc_8())

		# encrypted
		elif self.encryption_bit == 16:
			crc = self._crc_16()
			return chr(self.destination) + chr(self.length) + chr(crc & 0xff) + repr(self.payload) + chr((crc & 0xff00) >> 8)

	def __len__(self):
		return len(chr(self.destination) + chr(self.length) + chr(self.source) + repr(self.payload)) + 1

	def __repr__(self):
		return self.raw()

	def _crc_8(self):
		"""
		Calculates the checksum for the message
		"""
		data = chr(self.destination) + chr(self.length) + chr(self.source) + repr(self.payload)
		total = 0
		for byte in data:
			total = total + ord(byte)
		return 256 - (total % 256)

	@staticmethod
	def _verify_crc_8(data):
		"""
		Validates the checksum of a full message
		"""
		total = 0
		for byte in data[:-1]:
			total = total + ord(byte)
		return 256 - (total % 256) == ord(data[-1])

	def _crc_16(self, data=None):
		"""
		Calculates the CCITT checksum (CRC16) that can be used as a ccTalk
		checksuming algorithm
		"""
		if data is None:
			data = chr(self.destination) + chr(self.length) + repr(self.payload)
		crc = 0
		poly = 0x1021

		for c in data:
			crc ^= (ord(c) << 8) & 0xffff
			for x in range(8):
				if crc & 0x8000:
					crc = ((crc << 1) ^ poly) & 0xffff
				else:
					crc <<= 1
					crc &= 0xffff
		return crc

	def _verify_crc_16(self, data):
		"""
		Validates the CRC of a full message
		"""
		crc = ord(data[2]) + (ord(data[-1]) << 8)
		data = data[0:2] + data[3:-1]
		return crc == self._crc_16(data)


class Utilities(object):

	def __init__(self):
		self.log = None

	def _info(self, msg):
		self.log.info(msg)
		print(green(msg))

	def _error(self, msg):
		self.log.error(msg)
		print(red(msg))

	def _warn(self, msg):
		self.log.warning(msg)
		print(yellow(msg))

	@staticmethod
	def mail_queue(body):
		redis_db.lpush('mail-queue', body)

	@staticmethod
	def logger(log2file=None, stream=False):
		return logger(log2file=log2file, stream=stream)

	@doasync
	def _mail_worker(self):
		while True:
			mail = redis_db.brpop('mail-queue', 1)
			if not mail:
				continue

			body = mail[1]
			if self._is_internet_on():
				send_mail(body)
			else:
				redis_db.lpush('mail-queue', body)

	def _is_server_on(self):
		"""Backend readiness check.

		The backend gates /ping to localhost-only, so readiness is verified by
		ensuring we hold a valid ATM session - that proves the backend is
		reachable and this ATM is authenticated.
		"""
		if self._ensure_session():
			self._info('[*] server is ready, ATM session active.')
			return True
		self._error('[*] server not ready, could not establish ATM session.')
		return False

	def _is_internet_on(self, host="8.8.8.8", port=53, timeout=3):
		"""Check local internet connection over DNS
		"""
		if config.LINUX_PLATFORM:
			try:
				socket.setdefaulttimeout(timeout)
				socket.socket(socket.AF_INET, socket.SOCK_STREAM).connect((host, port))
			except Exception as ex:
				return False
			return True

		elif config.WINDOWS_PLATFORM:
			try:
				host = socket.gethostbyname('www.google.com')
				socket.create_connection((host, 80), timeout)
			except Exception as ex:
				return False
			return True

	def _create_session(self):
		"""Authenticate this ATM against the backend and cache the session token
		in memory. Returns True on success, False otherwise.

		Mirrors the kiosk login: POST create-session -> JWT, then
		GET session?token=<jwt> -> session token used as the `Auth-Token` header.
		"""
		username = client_config.ACCESS['user']
		try:
			created = requests.request(
				method='POST',
				url=config.LOCAL_BASE_URI + config.CREATE_SESSION_API,
				json={'username': username},
				timeout=config.SESSION_REQUEST_TIMEOUT,
			)
			if created.status_code != 200:
				self._error('[session] create-session failed for %s: HTTP %s' % (username, created.status_code))
				return False

			jwt_token = (created.json() or {}).get('data')
			if not jwt_token:
				self._error('[session] create-session returned no token for %s' % username)
				return False

			exchanged = requests.request(
				method='GET',
				url=config.LOCAL_BASE_URI + config.SESSION_API,
				params={'token': jwt_token},
				timeout=config.SESSION_REQUEST_TIMEOUT,
			)
			if exchanged.status_code != 200:
				self._error('[session] session exchange failed for %s: HTTP %s' % (username, exchanged.status_code))
				return False

			atm = (exchanged.json() or {}).get('data') or {}
			token = atm.get('token')
			if not token:
				self._error('[session] session exchange returned no session token for %s' % username)
				return False

			with _SESSION_LOCK:
				_SESSION['token'] = token
			self._info('[session] ATM %s authenticated; token cached in memory' % username)
			return True
		except Exception as e:
			self._error('[session] authentication error for %s: %s' % (username, e))
			return False

	@staticmethod
	def _get_token():
		with _SESSION_LOCK:
			return _SESSION['token']

	@staticmethod
	def _clear_token():
		with _SESSION_LOCK:
			_SESSION['token'] = None

	def _ensure_session(self):
		"""Make sure a session token is available, creating one if needed."""
		if self._get_token():
			return True
		return self._create_session()

	def make_http_request(self, method='post', url='/', data=None):
		"""Authenticated request to the backend.

		Sends `data` as a JSON body and the cached session token as the
		`Auth-Token` header. On a 401 (expired/missing session) it re-creates the
		session once, keeps the new token in memory, and retries the request.
		Returns the parsed JSON on a 2xx response, otherwise False.
		"""
		self._ensure_session()

		response = None
		for attempt in (1, 2):
			try:
				self._info('[*] request to server {}'.format(data))
				response = requests.request(
					method=method,
					url=config.LOCAL_BASE_URI + url,
					json=data,
					headers={'Auth-Token': self._get_token() or ''},
					timeout=None,
				)
			except Exception as e:
				self._error('communication failed with remote server, \ndata: {}\nerror: {}'.format(data, e))
				return False

			if response.status_code == 401 and attempt == 1:
				self._warn('[session] 401 received - session expired, re-authenticating')
				self._clear_token()
				if not self._create_session():
					return False
				continue
			break

		if not (200 <= response.status_code < 300):
			self._error('server returned HTTP {} for {}'.format(response.status_code, url))
			return False

		try:
			return response.json()
		except Exception as e:
			self._error('invalid JSON response from {}: {}'.format(url, e))
			return False

	@staticmethod
	def is_slot_valid(input):
		is_configured = False
		
		for i in constants.money_slots.slots:
			if i in input:
				is_configured = True
		
		for i in ['.', '#']:
			if i in input:
				is_configured = False
				
		return any(char.isdigit() for char in input) and is_configured

	@staticmethod
	def unescape(s):
		for _ in s:
			return _ if _.isalpha() else ''


class Transaction(Utilities):

	def __init__(self):
		super(Transaction, self).__init__()
		self.log = self.logger('transactions')

	def _confirm(self, uuid):
		try:
			self.log.info("transaction confirmation: {}".format(uuid))
			cur = sqlite_db.cursor()
			cur.execute(
				'''update transactions set checked = '{}' where uuid = '{}' '''.format(str(datetime.datetime.now()), uuid))
			sqlite_db.commit()
		except Exception as e:
			sqlite_db.rollback()
			self._error('transaction %s confirmation failed \nError: %s' % (uuid, e))
			return False
		return True

	def _add_local(self, value, uuid):

		try:
			cur = sqlite_db.cursor()
			cur.execute('''
					insert into
						transactions(uuid, created, value)
					values ("{}", "{}", "{}");'''.format(uuid, str(datetime.datetime.now()), value))
			sqlite_db.commit()
		except sqlite3.IntegrityError:
			sqlite_db.rollback()
			self._error('transaction already recorded: %s' % uuid)
			return False

		except Exception as e:
			sqlite_db.rollback()

			# ** send mail to administrator
			body = '''
			Greska u integritetu transakcije na <b>LOKALNOJ</b> bazi.<br/>
				TRANSACTION: {}<br/>
				ATM-ID:      {}<br/>
				VALUE:       {}<br/>
			'''.format(uuid, client_config.ACCESS['user'], value or '***')
			self.mail_queue(body)
			self._error('transaction %s of %s failed to save to local database \nError: %s' % (value, uuid, e))
			return False

		self._info('transaction %s of %s saved to local database' % (value, uuid))
		return True

	def _add_remote(self, value, uuid):
		# The backend identifies the ATM from the session (Auth-Token header),
		# so only the payment data is sent. Amount goes as a string to keep the
		# server-side Decimal conversion exact; `int_reference` is our local uuid.
		payload = {
			'amount': str(value),
			'int_reference': uuid,
			'mac_addr': str(client_config.ACCESS.get('mac', '')),
		}

		try:
			response = self.make_http_request(method='POST', url=config.TRANSACTION_API, data=payload)
			if not response:
				self._error('transaction %s of %s failed to save to remote database' % (value, uuid))
				return False

		except Exception as e:
			self._error('transaction %s of %s failed to save to remote database \nError: %s' % (value, uuid, e))
			return False

		self._info('transaction %s of %s saved to remote database' % (value, uuid))
		return True

	def make_payment(self, value):
		try:
			value = float(value)
		except Exception as e:
			self._error('invalid amount')
			return False

		uuid = str(
			hashlib.md5('{}_{}_{}'.format(client_config.ACCESS['user'], str(datetime.datetime.now()), value)).hexdigest())

		is_local_transaction_processed = self._add_local(value, uuid)
		is_remote_transaction_processed = self._add_remote(value, uuid)

		# ** if transaction not saved to remote database, send transaction to administrators
		if is_local_transaction_processed and not is_remote_transaction_processed:
			body = '''
			Transakcija upisana na aparatu ali nije na serveru - proveri:<br/>
				TRANSACTION: {}<br/>
				ATM-ID:      {}<br/>
				VALUE:       {}<br/>
			'''.format(uuid, client_config.ACCESS['user'], value or '***')
			self.mail_queue(body)
			return False

		if is_local_transaction_processed and is_remote_transaction_processed:
			# ** publish to web socket if transaction successfully added to local and remote database
			confirmed = self._confirm(uuid)
			if confirmed:
				return True
			return False
		return False


class Database(Utilities):

	def __init__(self):
		super(Database, self).__init__()
		self.log = self.logger('database')

	def sqlite3_connection(self):
		connection = self._sqlite3()
		if connection:
			self._info('[*] sqlite3 connection established.')
			return connection
		else:
			sys.exit('[*] connection failed on sqlite3 database.')

	def redis_connection(self):
		connection = self._redis()
		if connection:
			self._info('[*] redis connection established.')
			return connection
		else:
			sys.exit('[*] connection failed on redis database.')

	def _sqlite3(self):
		""" Make sqlitedb3 connection

		"""
		DB_DIR = config.DB_DIR + 'transactions-%s.db3' % args.device_type
		if os.path.exists(DB_DIR):
			os.rename(DB_DIR, '{}.{}'.format(DB_DIR, datetime.datetime.now().strftime("%Y%d%m%H%M%S")))

		if not os.path.exists(DB_DIR):
			db = sqlite3.connect(DB_DIR, check_same_thread=False)
			dbc = db.cursor()
			dbc.execute('''
				  CREATE TABLE transactions (
					  uuid TEXT NOT NULL UNIQUE,
					  created TEXT,
					  value REAL,
					  checked TEXT,
					  verified TEXT)
					''')
			db.commit()

			# ** change db permission to allow 'write'
			if config.LINUX_PLATFORM:
				os.system('chmod 0664 %s' % DB_DIR)
			return db
		else:
			return sqlite3.connect(DB_DIR, check_same_thread=False)

	def _redis(self):
		try:
			return redis.StrictRedis(retry_on_timeout=True, decode_responses=True)
		except Exception as e:
			self._error(e)
			return None


class Acceptor(threading.Thread, Transaction, Utilities):
	transaction_queue = set()

	def __init__(self):
		super(Acceptor, self).__init__()
		self.device = _serial_connection()
		self.terminated = False
		self.semaphore = threading.Lock()
		self.log = None

		self.destination_address = 999
		self.source_address = 999
		self.encryption_bit = 0
		self.tx_packets = {}

		self.configured_slots = {}
		self.event_counter = 0
		self.manufacturer = 'unknown'
		self.is_ready_to_accept = True

	def _compile_tx_packets(self):
		commands_list = dict()
		for p in commands_list:
			self.tx_packets[p] = commands_list[p]
		
	def _parse_messages(self, request, response):
		
		global COIN_RESPONSE_QUEUE
		global BILL_RESPONSE_QUEUE
		"""
		Parses a byte string to grab messages
		Returns a list containing all ccTalk messages found
		"""
		messages = []
		while len(response) > 0:
			try:
				length = ord(response[1])
				if len(response) < length + 5:
					break
				message = response[:length + 5]
				
				destination = ord(message[0])
				source = ord(message[2])
				
				if (destination == self.destination_address and source == 1) or (destination == 1 and source == self.destination_address):
					msg = CCTalkMessage(message, source=self.source_address, destination=self.destination_address, encryption_bit=self.encryption_bit)
					try:
						if request.raw() != msg.raw():
							as_list_msg = self.as_list(msg.raw())
							if as_list_msg[0] != 0:
								COIN_RESPONSE_QUEUE = self.as_list(msg.raw())
					except:
						pass
					
				elif destination == self.destination_address or destination == 1:
					msg = CCTalkMessage(message, source=self.source_address, destination=self.destination_address, encryption_bit=self.encryption_bit)
					try:
						if request.raw() != msg.raw():
							as_list_msg = self.as_list(msg.raw())
							if as_list_msg[0]  != 0:
								BILL_RESPONSE_QUEUE = self.as_list(msg.raw())
					except:
						pass
				
				else:
					#msg = CCTalkMessage(message, destination=self.destination_address, encryption_bit=self.encryption_bit)
					# print('za poruku', msg)
					# print('za dest', destination)
					# print('za source', source)
					#print(self.as_list(response.raw()), self.as_list(request.raw()))
					break
					
				messages.append(msg)
				response = response[length + 5:]
			except Exception as e:
				#self._error('error on cctalk-message: %s' % e)
				response = response[1:]
				continue
		return messages

	@staticmethod
	def as_list(payload):
		if payload:
			return list(map(ord, unpack('={0}c'.format(len(payload)), payload)))

	@staticmethod
	def as_bytes(payload):
		if payload:
			return pack('=%s' % ('c' * len(payload)), *list(map(chr, payload)))
		
	def _read_buffered_credit_or_error_codes(self):
		rx = self.request('read_buffered_credit_or_error_codes')
		
		# ako je multimaster nema nista u response,
		# vec se vadi odgovor iz queue-a preko self.response() methode
		if args.device_type == 'multimaster':
			return self.response()
		
		# Ovo se koristi za id003 protocol.
		# Odmah se vraca response. Ne stavlja se poruka u global queue
		return rx
	
	def response(self):
		global COIN_RESPONSE_QUEUE
		global BILL_RESPONSE_QUEUE
		
		if self.__class__.__name__ in ['CCtalkBillAcceptor', 'ID003BillAcceptor'] and BILL_RESPONSE_QUEUE:
			res = BILL_RESPONSE_QUEUE
			BILL_RESPONSE_QUEUE = None
			self.log.warn('citam bill')
			return res
		
		if self.__class__.__name__ == 'CCTalkCoinAcceptor' and COIN_RESPONSE_QUEUE:
			res = COIN_RESPONSE_QUEUE
			COIN_RESPONSE_QUEUE = None
			self.log.warn('citam coin')
			return res
		return None
	
	def request(self, action=None, timeout=1, wait_after=0.0):

		# find command
		tx = self.tx_packets.get(action)
		if not tx:
			return []

		# lock GIL
		self.semaphore.acquire()

		# write to device
		self.device.reset_input_buffer()
		self.device.reset_output_buffer()
		self.device.write(tx.raw())

		self._info('REQUEST %s' % self.as_list(tx.raw()))
		
		rx = []
		
		time.sleep(0.05)
		start = time.time()
		while not self.terminated:
			elapsed = time.time() - start
			if elapsed > timeout:
				break

			pending_bytes = self.device.inWaiting()
			if pending_bytes:
				if args.protocol == 'cctalk':
					rx = self._parse_messages(tx, self.device.read(pending_bytes))
					
					if rx:
						rx = self.as_list(rx[-1].raw())
						
					if config.VERBOSE and rx:
						self._info('RESPONSE %s' % (rx,))

				elif args.protocol == 'id003':
					rx = self.as_list(self.device.read(pending_bytes))
					if config.VERBOSE and rx:
						self._info('RESPONSE %s' % (rx, ))

				break
				
		self.semaphore.release()
		time.sleep(wait_after)
	
		return rx
	
	def _boot_device(self):
		raise NotImplementedError

	@doasync
	def _transactions_queue(self):

		transaction = Transaction()

		while True:
			while self.transaction_queue:
				item = self.transaction_queue.pop()
				self._warn('[*] found %s' % item)
				transaction.make_payment(value=item)
				time.sleep(0.1)
			time.sleep(0.05)

	@doasync
	def _is_internet_connection_available(self):
		"""Check local internet connection every 1 second in loop.
		If probe fails, disable cash-acceptor and send message to frontend to block UI, and wait for connection

		"""
		
		while True:
			if self.device and self.device.isOpen():
				net = self._is_internet_on()
				if not net and not self.terminated:
					self._error('no internet connection...')
					self.stop_device()
				elif net and self.terminated:
					self.start_device()
			time.sleep(0.5)

	@doasync
	def _is_acceptor_connected(self):
		while True:
			try:
				self.device.inWaiting()
			except:
				sys.exit(red(red('[*] device not connected!')))
			time.sleep(1)

	def start_device(self):
		raise NotImplementedError

	def stop_device(self):
		raise NotImplementedError

	def restart_device(self):
		self.stop_device()
		self.start_device()

	def kill(self, reason='acceptor killed'):
		self.terminated = True
		self._error(reason)
		self.device.close()

	def compile_msg(self, header, payload=None, **kw):
		forced_destination = kw.get('forced_destination')
		
		if args.protocol == 'cctalk':
			if payload:
				byte_msg = list(map(chr, payload))
				return CCTalkMessage(payload=pack('=%s' % ('c' * len(payload)), *byte_msg), header=header, source=self.source_address, destination=forced_destination if forced_destination else self.destination_address, encryption_bit=self.encryption_bit)
			return CCTalkMessage(header=header, source=self.source_address, destination=forced_destination if forced_destination else self.destination_address, encryption_bit=self.encryption_bit)

		elif args.protocol == 'id003':
			if payload:
				return ID003Message(data=payload[0], header=header)
			return ID003Message(header=header)

	def spawn_daemons(self):
		while not self._is_internet_on() or not self._is_server_on():
			self.stop_device()
			time.sleep(1)

		self._is_internet_connection_available()

		self._mail_worker()

		self._transactions_queue()


class CCTalkCoinAcceptor(Acceptor):

	def __init__(self):
		super(CCTalkCoinAcceptor, self).__init__()
		self.destination_address = config.COIN_ACCEPTOR_DESTINATION_ADDRESS
		self.source_address = config.COIN_ACCEPTOR_SOURCE_ADDRESS
		self.encryption_bit = config.COIN_ACCEPTOR_ENCRYPTION_BIT
		self.log = logger('coin')

	def _compile_tx_packets(self):

		commands_list = dict(
			factory_set_up_and_test=self.compile_msg(header=cctalk_headers.K2N['FACTORY_SET_UP_AND_TEST']),
			clear_comms_status_variables=self.compile_msg(header=cctalk_headers.K2N['CLEAR_COMMS_STATUS_VARIABLES']),
			manufacturer_id=self.compile_msg(header=cctalk_headers.K2N['REQUEST_MANUFACTURER_ID']),
			serial_number=self.compile_msg(header=cctalk_headers.K2N['REQUEST_SERIAL_NUMBER']),
			software_revision=self.compile_msg(header=cctalk_headers.K2N['REQUEST_SOFTWARE_REVISION']),
			equipment_category=self.compile_msg(header=cctalk_headers.K2N['REQUEST_EQUIPMENT_CATEGORY_ID']),
			simple_poll=self.compile_msg(header=cctalk_headers.K2N['SIMPLE_POLL']),

			master_inhibit_status_on=self.compile_msg(header=cctalk_headers.K2N['MODIFY_MASTER_INHIBIT_STATUS'], payload=[1]),
			master_inhibit_status_off=self.compile_msg(header=cctalk_headers.K2N['MODIFY_MASTER_INHIBIT_STATUS'], payload=[0]),
			enable_slots=self.compile_msg(header=cctalk_headers.K2N['MODIFY_INHIBIT_STATUS'], payload=[255, 255]),
			disable_slots=self.compile_msg(header=cctalk_headers.K2N['MODIFY_INHIBIT_STATUS'], payload=[0]),
			reset_device=self.compile_msg(header=cctalk_headers.K2N['RESET_DEVICE']),

			read_buffered_credit_or_error_codes=self.compile_msg(header=cctalk_headers.K2N['READ_BUFFERED_CREDIT_OR_ERROR_CODES']),

			request_slot_1=self.compile_msg(header=cctalk_headers.K2N['REQUEST_COIN_ID'], payload=[1]),
			request_slot_2=self.compile_msg(header=cctalk_headers.K2N['REQUEST_COIN_ID'], payload=[2]),
			request_slot_3=self.compile_msg(header=cctalk_headers.K2N['REQUEST_COIN_ID'], payload=[3]),
			request_slot_4=self.compile_msg(header=cctalk_headers.K2N['REQUEST_COIN_ID'], payload=[4]),
			request_slot_5=self.compile_msg(header=cctalk_headers.K2N['REQUEST_COIN_ID'], payload=[5]),
			request_slot_6=self.compile_msg(header=cctalk_headers.K2N['REQUEST_COIN_ID'], payload=[6]),
			request_slot_7=self.compile_msg(header=cctalk_headers.K2N['REQUEST_COIN_ID'], payload=[7]),
			request_slot_8=self.compile_msg(header=cctalk_headers.K2N['REQUEST_COIN_ID'], payload=[8]),
			request_slot_9=self.compile_msg(header=cctalk_headers.K2N['REQUEST_COIN_ID'], payload=[9]),
			request_slot_10=self.compile_msg(header=cctalk_headers.K2N['REQUEST_COIN_ID'], payload=[10]),
			request_slot_11=self.compile_msg(header=cctalk_headers.K2N['REQUEST_COIN_ID'], payload=[11]),
			request_slot_12=self.compile_msg(header=cctalk_headers.K2N['REQUEST_COIN_ID'], payload=[12]),
			request_slot_13=self.compile_msg(header=cctalk_headers.K2N['REQUEST_COIN_ID'], payload=[13]),
			request_slot_14=self.compile_msg(header=cctalk_headers.K2N['REQUEST_COIN_ID'], payload=[14]),
			request_slot_15=self.compile_msg(header=cctalk_headers.K2N['REQUEST_COIN_ID'], payload=[15]),
			request_slot_16=self.compile_msg(header=cctalk_headers.K2N['REQUEST_COIN_ID'], payload=[16]),
			address_change_2_to_128=self.compile_msg(header=cctalk_headers.K2N['ADDRESS_CHANGE'], payload=[config.COIN_ACCEPTOR_DESTINATION_ADDRESS], forced_destination=2),
		)

		for p in commands_list:
			self.tx_packets[p] = commands_list[p]

	def start_device(self):
		self.request('reset_device', wait_after=.2)
		self.request('enable_slots', wait_after=.2)
		self.request('master_inhibit_status_on')
		self.terminated = False
		self.is_ready_to_accept = True

	def stop_device(self):
		self.terminated = True
		self.is_ready_to_accept = False
		self.request('disable_slots', wait_after=.2)
		self.request('master_inhibit_status_off')
		self.event_counter = 0

	def _boot_device(self):

		if self.device and not self.device.isOpen():
			sys.exit(red(red('[*] device not connected!')))

		self._compile_tx_packets()
		
		# ako je nov uredjaj, pregazi default destination port 2 i stavi ga na 128
		self.request('address_change_2_to_128')

		self._info('[*] connection success on %s [%s]' % (self.device.port, self.device.baudrate))
		
		#########################
		# INITIALIZATION COMMANDS
		#########################
		initialization_commands = [
			'reset_device',
			#'factory_set_up_and_test',
			#'simple_poll',
			'clear_comms_status_variables',
			'manufacturer_id',
			'disable_slots',
		]
		error = 0
		for cmd in initialization_commands:
			self.request(cmd, wait_after=.2)
			_response = self.as_bytes(self.response())
			if _response:
				if cmd == 'manufacturer_id':
					self.manufacturer = ''.join(map(self.unescape, _response.strip()))
					self._info('[*] manufacturer: %s' % self.manufacturer)

			else:
				error += 1
				self._error('[*] empty response')

		if error == len(initialization_commands):
			print(red('[*] Acceptor closed. Invalid connection!'))
			self.device.close()
			sys.exit()
		
		###################
		# MONEY SLOT MAPPER
		###################
		for slot in range(1, 17):
			self.request('request_slot_%s' % slot, wait_after=.1)
			_response = self.as_bytes(self.response())
			if _response:
				if self.is_slot_valid(_response):
					self.configured_slots[slot] = _response[4:10]
					self._info('[*] found %s on slot[%s]' % (_response[4:10], slot))
		if not self.configured_slots:
			print(red('[*] Acceptor closed. Invalid connection!'))
			self.device.close()
			sys.exit()
			
		self.spawn_daemons()

	def run(self):
		self._boot_device()
		self.request('enable_slots', wait_after=.2)
		self.request('master_inhibit_status_on')
		
		self._info('=' * 50)
		self._warn('[*] Initialization done. waiting for money...')

		while True:
			while not self.terminated and self.is_ready_to_accept:
				try:
					rx = self._read_buffered_credit_or_error_codes()
					if rx and len(rx) == 16:
						msg = rx
						
						if msg[4] != self.event_counter:
							self.event_counter = msg[4]
	
							self.request('disable_slots')
	
							if self.event_counter == 5:
								if self.manufacturer in ['MSC', 'CMG']:
									self.request('reset_device', wait_after=.2)
									self.request('factory_set_up_and_test')
								else:
									self.request('reset_device')
	
								self.event_counter = 0
	
							# microcoinSP
							if self.manufacturer in ['MSC', 'CMG']:
								if msg[6] in [254]:
									print('bumper!')
								if msg[6] in [137]:
									print('rejected....')
	
								code = self.configured_slots.get(msg[5], None)
								if code:
									self.transaction_queue.add(constants.money_slots.slots[code])
	
							# svi ostali akecptori
							else:
								for byte in range(5, 15):
									if byte % 2 == 0:
										if msg[byte]:
											print('rejected coin...', msg)
									else:
										if msg[byte]:
											code = self.configured_slots[msg[byte]]
											self.transaction_queue.add(constants.money_slots.slots[code])
	
							if self.manufacturer not in ['CMG']:
								self.request('reset_device')
	
							if self.manufacturer in ['MSC']:
								time.sleep(.2)
	
							self.request('enable_slots')
							self.request('master_inhibit_status_on')
	
					time.sleep(config.COIN_ACCEPTOR_MAIN_LOOP_SLEEP)
					
				except Exception as er:
					if isinstance(er, SerialException):
						print('idemoooooooooooooo')
						self.restart_device()
					print(self.__class__.__name__, er, type(er))
					self.log.critical(er)


class CCtalkBillAcceptor(Acceptor):
	def __init__(self):
		super(CCtalkBillAcceptor, self).__init__()
		self.destination_address = config.BILL_ACCEPTOR_DESTINATION_ADDRESS
		self.source_address = config.BILL_ACCEPTOR_SOURCE_ADDRESS
		self.encryption_bit = config.BILL_ACCEPTOR_ENCRYPTION_BIT
		self.log = logger('bill')

	def _compile_tx_packets(self):

		commands_list = dict(
			factory_set_up_and_test=self.compile_msg(header=cctalk_headers.K2N['FACTORY_SET_UP_AND_TEST']),
			clear_comms_status_variables=self.compile_msg(header=cctalk_headers.K2N['CLEAR_COMMS_STATUS_VARIABLES']),
			manufacturer_id=self.compile_msg(header=cctalk_headers.K2N['REQUEST_MANUFACTURER_ID']),
			serial_number=self.compile_msg(header=cctalk_headers.K2N['REQUEST_SERIAL_NUMBER']),
			software_revision=self.compile_msg(header=cctalk_headers.K2N['REQUEST_SOFTWARE_REVISION']),
			equipment_category=self.compile_msg(header=cctalk_headers.K2N['REQUEST_EQUIPMENT_CATEGORY_ID']),
			simple_poll=self.compile_msg(header=cctalk_headers.K2N['SIMPLE_POLL']),

			master_inhibit_status_on=self.compile_msg(header=cctalk_headers.K2N['MODIFY_MASTER_INHIBIT_STATUS'], payload=[1]),
			master_inhibit_status_off=self.compile_msg(header=cctalk_headers.K2N['MODIFY_MASTER_INHIBIT_STATUS'], payload=[0]),
			enable_slots=self.compile_msg(header=cctalk_headers.K2N['MODIFY_INHIBIT_STATUS'], payload=[255, 255]),
			disable_slots=self.compile_msg(header=cctalk_headers.K2N['MODIFY_INHIBIT_STATUS'], payload=[0]),
			reset_device=self.compile_msg(header=cctalk_headers.K2N['RESET_DEVICE']),
			perform_self_check=self.compile_msg(header=cctalk_headers.K2N['PERFORM_SELF_CHECK']),

			read_buffered_credit_or_error_codes=self.compile_msg(header=cctalk_headers.K2N['READ_BUFFERED_BILL_EVENTS']),

			request_bill_id_1=self.compile_msg(header=cctalk_headers.K2N['REQUEST_BILL_ID'], payload=[1]),
			request_bill_id_2=self.compile_msg(header=cctalk_headers.K2N['REQUEST_BILL_ID'], payload=[2]),
			request_bill_id_3=self.compile_msg(header=cctalk_headers.K2N['REQUEST_BILL_ID'], payload=[3]),
			request_bill_id_4=self.compile_msg(header=cctalk_headers.K2N['REQUEST_BILL_ID'], payload=[4]),
			request_bill_id_5=self.compile_msg(header=cctalk_headers.K2N['REQUEST_BILL_ID'], payload=[5]),
			request_bill_id_6=self.compile_msg(header=cctalk_headers.K2N['REQUEST_BILL_ID'], payload=[6]),
			request_bill_id_7=self.compile_msg(header=cctalk_headers.K2N['REQUEST_BILL_ID'], payload=[7]),
			request_bill_id_8=self.compile_msg(header=cctalk_headers.K2N['REQUEST_BILL_ID'], payload=[8]),
			request_bill_id_9=self.compile_msg(header=cctalk_headers.K2N['REQUEST_BILL_ID'], payload=[9]),
			request_bill_id_10=self.compile_msg(header=cctalk_headers.K2N['REQUEST_BILL_ID'], payload=[10]),

			request_country_scaling_factor=self.compile_msg(header=cctalk_headers.K2N['REQUEST_COUNTRY_SCALING_FACTOR'], payload=[69,85]),
			request_currency_revision=self.compile_msg(header=cctalk_headers.K2N['REQUEST_CURRENCY_REVISION'], payload=[69,85]),
			modify_bill_operating_mode=self.compile_msg(header=cctalk_headers.K2N['MODIFY_BILL_OPERATING_MODE'], payload=[3]), #  NO ESCROW NO STACKER 3 = both enabled 2 = only stacker

			return_from_escrow=self.compile_msg(header=cctalk_headers.K2N['ROUTE_BILL'], payload=[0]),
			stack_from_escrow=self.compile_msg(header=cctalk_headers.K2N['ROUTE_BILL'], payload=[1]),
			hold_in_escrow=self.compile_msg(header=cctalk_headers.K2N['ROUTE_BILL'], payload=[0]),
			address_change=self.compile_msg(header=cctalk_headers.K2N['ADDRESS_CHANGE'], payload=[config.BILL_ACCEPTOR_DESTINATION_ADDRESS]),
		)

		for p in commands_list:
			self.tx_packets[p] = commands_list[p]

	def start_device(self):
		self.request('master_inhibit_status_on')
		self.request('enable_slots')
		#self.request('perform_self_check')
		self.terminated = False
		self.is_ready_to_accept = True

	def stop_device(self):
		self.terminated = True
		self.is_ready_to_accept = False
		self.request('return_from_escrow', wait_after=1)

	"""
	    Bill type 1 to 255  0  validated correctly and sent to cashbox / stacker Credit
	    1 to 255 1 Bill type 1 to 255 validated correctly and held in escrow Pending Credit
	    0 0 Master inhibit active Status
	    0 1 Bill returned from escrow Status
	    0 2 Invalid bill ( due to validation fail ) Reject
	    0 3 Invalid bill ( due to transport problem ) Reject
	    0 4 Inhibited bill ( on serial ) Status
	    0 5 Inhibited bill ( on DIP switches ) Status
	    0 6 Bill jammed in transport ( unsafe mode ) Fatal Error
	    0 7 Bill jammed in stacker Fatal Error
	    0 8 Bill pulled backwards Fraud Attempt
	    0 9 Bill tamper Fraud Attempt
	    0 10 Stacker OK Status
	    0 11 Stacker removed Status
	    0 12 Stacker inserted Status
	    0 13 Stacker faulty Fatal Error
	    0 14 Stacker full Status
	    0 15 Stacker jammed Fatal Error
	    0 16 Bill jammed in transport ( safe mode ) Fatal Error
	    0 17 Opto fraud detected Fraud Attempt
	    0 18 String fraud detected Fraud Attempt
	    0 19 Anti-string mechanism faulty Fatal Error
	    0 20 Barcode detected Status
	    0 21 Unknown bill type stacked Status
	"""

	def _boot_device(self):

		if self.device and not self.device.isOpen():
			sys.exit(red('[*] device not connected!'))

		self._compile_tx_packets()

		self.request('address_change')

		self._info('[*] connection success on %s [%s]' % (self.device.port, self.device.baudrate))
		
		#########################
		# INITIALIZATION COMMANDS
		#########################
		initialization_commands = [
			#'factory_set_up_and_test',
		#	'simple_poll',
			'manufacturer_id',
			'request_country_scaling_factor',
			'request_currency_revision',
			'modify_bill_operating_mode',
			'master_inhibit_status_on',
			'enable_slots',
			#'perform_self_check'
		]

		error = 0
		for cmd in initialization_commands:
			self.request(cmd, wait_after=.1)
			_response = self.as_bytes(self.response())
			if _response:
				if _response and cmd == 'manufacturer_id':
					self.manufacturer = ''.join(map(self.unescape, _response))
					self._info('[*] manufacturer: %s' % self.manufacturer)
			else:
				error += 1
				self._error('[*] empty response')

		if error >= len(initialization_commands)-2:
			print(red('[*] Acceptor closed. Invalid connection!'))
			self.device.close()
			sys.exit()

		###################
		# MONEY SLOT MAPPER
		###################
		for slot in range(1, 10):
			self.request('request_bill_id_%s' % slot, wait_after=.1)
			_response = self.as_bytes(self.response())
			if _response:
				if self.is_slot_valid(_response):
					self.configured_slots[slot] = _response[4:-2]
					self._info('[*] found %s on slot[%s]' % (_response[4:-2], slot))
		
		if not self.configured_slots:
			print(red('[*] Acceptor closed. Invalid connection!'))
			self.device.close()
			sys.exit()
			
		self.spawn_daemons()

	def run(self):
		self._boot_device()

		self.request('address_change')

		self._info('=' * 50)
		self._warn('[*] Initialization done. waiting for money...')

		is_bill_in_escrow = False
		while True:
			while not self.terminated and self.is_ready_to_accept:
				
				try:
					rx = self._read_buffered_credit_or_error_codes()
					if rx and len(rx) > 6:
						msg = rx
	
						if msg[4] != self.event_counter:
							self.event_counter = msg[4]
	
							money_slot = msg[5]
							if not money_slot:
								continue
	
							if not self.is_ready_to_accept:
								self.request('return_from_escrow', wait_after=1)
								continue
	
							validator_response_id = msg[6]
	
							# Stacker full Status
							if validator_response_id == 14:
								self.mail_queue('''Stacker Bill Acceptora je popunjen, obavestiti <b>{}</b>'''.format(client_config.ACCESS['user']))
								self.request('return_from_escrow')
								continue
	
							# accepting money (escrow state)
							if validator_response_id == 1:
								is_bill_in_escrow = True
								self.request('stack_from_escrow')
	
							# money accepted and ready to make payment (stacker state)
							if is_bill_in_escrow and validator_response_id == 0:
								if self.configured_slots[money_slot]:
									id_slot = self.configured_slots[money_slot]
									self.transaction_queue.add(constants.money_slots.slots[id_slot])
									is_bill_in_escrow = False
									
					time.sleep(config.BILL_ACCEPTOR_MAIN_LOOP_SLEEP)
				except Exception as er:
					if isinstance(er, SerialException):
						print('idemoooooooooooooo')
						self.restart_device()
					
					print(self.__class__.__name__, er, type(er))
					self.log.critical(er)


class ID003BillAcceptor(Acceptor):
	def __init__(self):
		super(ID003BillAcceptor, self).__init__()
		self.log = logger('bill')

	def _compile_tx_packets(self):

		commands_list = dict(
			read_buffered_credit_or_error_codes=self.compile_msg(header=id003_headers.POOL),
			reset=self.compile_msg(header=id003_headers.OC_RESET),
			version_request=self.compile_msg(header=id003_headers.SS_VERSION_REQUEST),
			acc_disabled=self.compile_msg(header=id003_headers.OC_RESET),

			enable=self.compile_msg(header=id003_headers.SC_INHIBIT, payload=[id003_headers.ENABLE]),
			disable=self.compile_msg(header=id003_headers.SC_INHIBIT, payload=[id003_headers.DISABLE]),

			sc_enable_disable=self.compile_msg(header=id003_headers.SC_ENABLE_DISABLE, payload=[id003_headers.ENABLED_DENOMINATION]),
			sc_security=self.compile_msg(header=id003_headers.SC_SECURITY, payload=[id003_headers.SECURITY_MODE]),
			sc_op_function=self.compile_msg(header=id003_headers.SC_OP_FUNCTION, payload=[id003_headers.ENABLE_OPTION_FUNCTIONS]),
			sc_comm_mode=self.compile_msg(header=id003_headers.SC_COMM_MODE, payload=[id003_headers.COMMUNICATION_MODE]),
			sc_inhibit=self.compile_msg(header=id003_headers.SC_INHIBIT, payload=[id003_headers.ENABLE]),
			sc_bar_inhibit=self.compile_msg(header=id003_headers.SC_BAR_INHIBIT, payload=[id003_headers.BAR_INHIBIT]),

			power_up_with_bill=self.compile_msg(header=id003_headers.OC_RESET),
			power_up=self.compile_msg(header=id003_headers.SS_VERSION_REQUEST),
			stacking=self.compile_msg(header=id003_headers.OC_STACK1),
			stacked=self.compile_msg(header=id003_headers.POOL),
			reject=self.compile_msg(header=id003_headers.POOL),
			return_bill=self.compile_msg(header=id003_headers.OC_RETURN),
			stacker_full=self.compile_msg(header=id003_headers.POOL),
			cash_box_removed=self.compile_msg(header=id003_headers.POOL),
			jam_in_acceptor=self.compile_msg(header=id003_headers.POOL),
			jam_in_stacker=self.compile_msg(header=id003_headers.POOL),
			two_bills_pause=self.compile_msg(header=id003_headers.POOL),
			acc_cheated=self.compile_msg(header=id003_headers.POOL),
			acc_failure=self.compile_msg(header=id003_headers.POOL),
			communication_error_handler=self.compile_msg(header=id003_headers.POOL),
			escrow=self.compile_msg(header=id003_headers.POOL),
			drawing_bill=self.compile_msg(header=id003_headers.POOL),
			bad_cmd_received=self.compile_msg(header=id003_headers.POOL),
			acknowledge=self.compile_msg(header=id003_headers.OCR_ACK),
		)

		for p in commands_list:
			self.tx_packets[p] = commands_list[p]

	def start_device(self):
		self.request('enable')
		self.terminated = False
		self.is_ready_to_accept = True

	def stop_device(self):
		self.is_ready_to_accept = False
		self.terminated = True
		self.request('return_bill')
		self.request('reset')
		self.request('acc_disabled')
		self.request('disable', wait_after=1)

	def reset(self):
		self.terminated = True
		self.is_ready_to_accept = False
		self.request('reset')
		self.terminated = False
		self.is_ready_to_accept = True

	def _boot_device(self):

		if self.device and not self.device.isOpen():
			sys.exit(red(red('[*] device not connected!')))

		self._compile_tx_packets()

		self._info('[*] connection success on %s [%s]' % (self.device.port, self.device.baudrate))
		for cmd in [
			'acc_disabled',
			'sc_enable_disable',
			'sc_security',
			'sc_op_function',
			'sc_comm_mode',
			'sc_inhibit',
			'sc_bar_inhibit']:

			self.request(cmd, wait_after=.2)
			_response = self.response()
			
			if _response:
				if cmd == 'manufacturer_id':
					self.manufacturer = ''.join(map(self.unescape, _response.strip()))
					self._info('[*] manufacturer: %s' % self.manufacturer)
			else:
				self._error('[*] empty response')

		self.spawn_daemons()
		
	def run(self):
		self._boot_device()

		last_rx = None
		last_valid_bill = 0
		while True:
			while not self.terminated and self.is_ready_to_accept:
				try:
					response = None
					rx = self._read_buffered_credit_or_error_codes()
					if rx:
						response = rx[2]

					if last_rx != rx and response:
						last_rx = rx

						if response == id003_headers.SR_INITIALIZING:
							self._warn('initializing...')
						else:
							self._warn('ready...')

						if response == id003_headers.SR_ENABLE:
							self.request('read_buffered_credit_or_error_codes')

						# power up
						elif response == id003_headers.PUSP_POWERUP:
							self.request('power_up')

						# power up with bill in acceptor
						elif rx in [id003_headers.PUSP_POWERUP_WBA,id003_headers.PUSP_POWERUP_WBS]:
							self.request('power_up_with_bill')

						# bad_command
						elif response == id003_headers.OCR_INVALID_CMD:
							self.request('bad_cmd_received')

						# disabled
						elif response == id003_headers.SR_DISABLED:
							self.request('acc_disabled')

						# ** 1 - acceptor drawing the bill
						elif response == id003_headers.SR_ACCEPTING:
							pass#print('\nSR_ACCEPTING\n')

						# ** 2 - escrow - bill info
						elif response == id003_headers.SR_ESCROW:
							money_slot = rx[3]
							if money_slot in constants.money_slots.id003_slots:
								last_valid_bill = constants.money_slots.id003_slots[money_slot]
								self.request('stacking')
							else:
								self.request('return_bill')

						# ** 3 -stacking the bill
						elif response == id003_headers.SR_STACKING:
							self.request('stacked')
							
						# ** 3 - do transactions
						elif response == id003_headers.SR_VEND_VALID:
							if last_valid_bill:
								self.transaction_queue.add(last_valid_bill)
								last_valid_bill = 0
								self.request('acknowledge')

						# finish stacking operation
						elif response == id003_headers.SR_STACKED:
							self.request('stacked')

						# rejecting process
						elif response == id003_headers.SR_REJECTING:
							self.request('reject')

						# returning process
						elif response == id003_headers.SR_RETURNING:
							self.request('return_bill')

						# # ERRORS:
						# # stacker full
						elif response == id003_headers.ESR_STACKER_FULL:
							self.request('stacker_full')

						# cashbox removed (or not properly installed)
						elif response == id003_headers.ESR_STACKER_OPEN:
							self.request('cashbox_removed')

						# jam in acceptor
						elif response == id003_headers.ESR_JAM_IN_ACCEPTOR:
							self.request('jam_in_acceptor')

						# jam in stacker
						elif response == id003_headers.ESR_JAM_IN_STACKER:
							self.request('jam_in_stacker')

						# pause - two bills inserted
						elif response == id003_headers.ESR_PAUSE:
							self.request('two_bills_pause')

						# cheated
						elif response == id003_headers.ESR_CHEATED:
							self.request('acc_cheated')

						# failure, abnormal condition or incorrect settings
						elif response == id003_headers.ESR_FAILURE:
							self.request('acc_failure')

						# communication error
						elif response == id003_headers.ESR_COMMUNICATION_ERROR:
							self.request('communication_error_handler')

					time.sleep(config.BILL_ACCEPTOR_MAIN_LOOP_SLEEP)

				except Exception as er:
					self.restart_device()
					print('\n\n')
					print('poruka nije validna')
					print('\n\n')
					self.log.critical(er)
			time.sleep(0.01)


if __name__ == '__main__':

	args = argparse.ArgumentParser(
		prog='Bill/Coin Validator',
		description='Program must be executed with ROOT privileges.',
		usage='./run.py -p '.format(serial_ports())
	)
	args.add_argument('-p', dest='port', help='enter serial port', required=True)
	args.add_argument('-t', dest='device_type', help='coin | bill | multimaster', required=True, choices=['bill', 'coin', 'multimaster'])
	args.add_argument('-o', dest='protocol', help='[cctalk] | id003', required=False, default='cctalk', choices=['cctalk', 'id003'])
	args = args.parse_args()
	
	is_port_found = False
	attempt = 0

	print(green('[*] available ports:'))
	for _port in list(serial.tools.list_ports.comports()):
		print(green('\t* ' + str(_port)))
		
	while not is_port_found:
		for _port in list(serial.tools.list_ports.comports()):
			if args.device_type == 'bill':
				if client_config.BILL_PORT in _port:
					is_port_found = True
					break
					
			if args.device_type == 'coin':
				if client_config.COIN_PORT in _port:
					is_port_found = True
					break
					
			if args.device_type == 'multimaster':
				if args.port in _port:
					is_port_found = True
					break
		attempt += 1
		if attempt == 30:
			sys.exit(red('[*] port is not available for %s acceptor!Exiting...' % args.device_type))
		time.sleep(.2)
	
	if is_port_found:
		print(green('[*] port %s is found and configured properly. \n[*] connecting...' % args.port))
		
	# make sure that these folder are created
	for _dir in ['log', 'lock', 'db']:
		if config.LINUX_PLATFORM:
			if not os.path.exists(config.BASE_DIR + '/var/' + _dir):
				os.system('mkdir -p %s' % config.BASE_DIR + '/var/' + _dir)
		if config.WINDOWS_PLATFORM:
			if not os.path.exists(config.BASE_DIR + '\\var\\' + _dir):
				os.mkdir(config.BASE_DIR + '\\var\\' + _dir)

	# check if acceptor already running
	if not lock_acceptor(args.device_type):
		sys.exit(red('%s acceptor is already running..' % args.device_type))

	# check database connections
	db = Database()
	sqlite_db = db.sqlite3_connection()
	redis_db = db.redis_connection()

	# establish the backend ATM session on startup (kept in memory, refreshed on 401)
	if db._create_session():
		db._info('[session] backend session established for %s' % client_config.ACCESS['user'])
	else:
		db._warn('[session] no backend session on startup; will retry on first request')

	# connect to serial port
	validator_instances = []
	
	def _serial_connection():
		_device = None
		_connection_time = time.time()

		while True:
			try:
				if args.protocol == 'cctalk':
					_device = Serial(devfile=args.port, parity=serial.PARITY_NONE).connection()
				elif args.protocol == 'id003':
					_device = Serial(devfile=args.port, parity=serial.PARITY_EVEN).connection()
				else:
					_device = Serial(devfile=args.port, parity=serial.PARITY_NONE).connection()

				if _device.isOpen():
					_connection_time -= time.time()
					return _device

				time.sleep(0.3)
			except Exception as e:
				try:
					_device.close()
				except Exception as e:
					pass
				time.sleep(0.3)
				continue

	# make acceptor instance
	if args.device_type == 'multimaster':
		validator_instances = [CCtalkBillAcceptor(), CCTalkCoinAcceptor()]
	else:
		if args.device_type == 'coin':
			validator_instances = [CCTalkCoinAcceptor()]
		elif args.device_type == 'bill':
			if args.protocol == 'cctalk':
				validator_instances = [CCtalkBillAcceptor()]
			elif args.protocol == 'id003':
				validator_instances = [ID003BillAcceptor()]
		else:
			sys.exit(red('unknown acceptor type'))

	def kill_acceptor(sig=None, frame=None):
		try:
			print(red('blocking device...'))
			for acc in validator_instances:
				print(acc.kill())
		except Exception as e:
			pass

		try:
			print('{}{}.lock'.format(config.LOCK_DIR, args.device_type))
			os.remove('{}{}.lock'.format(config.LOCK_DIR, args.device_type))
		except Exception as e:
			print(e)
			pass

		sys.exit(red('acceptor stopped!'))
	
	# ignore Broken Pipe signal
	signal.signal(signal.SIGPIPE, signal.SIG_IGN)
	
	# catch kill signal
	signal.signal(signal.SIGINT, kill_acceptor)
	signal.signal(signal.SIGQUIT, kill_acceptor)
	signal.signal(signal.SIGTERM, kill_acceptor)
	signal.signal(signal.SIGHUP, kill_acceptor)
	
	try:
		for i in validator_instances:
			i.start()
			time.sleep(5)
	except (KeyboardInterrupt, Exception) as e:
		print(e)
		kill_acceptor()
