#!/usr/bin/env python3

import datetime
import os
import pickle
import signal
import subprocess
import tempfile

import tornado.httpclient
import tornado.httpserver
import tornado.ioloop
import tornado.web

import config
from utilities.database import redis_db
from utilities.extra import logger
from utilities.service import status_error, status_ok
from utilities.string import decompress_text, green, red
from utilities.printer import Ticket

from tornado.options import define, options

define("printer", default="/dev/null", help="printer handler")


def _raw_dest(target):
    r"""Razresi --printer u odrediste za `copy /B`:
      - UNC (\\PC\share) ili port (LPT1/COM1) -> kako jeste
      - samo share name (npr. 'oki')          -> \\COMPUTERNAME\oki
    """
    t = (target or '').strip()
    up = t.upper()
    if up.startswith('LPT') or up.startswith('COM'):
        return t if t.endswith(':') else t + ':'   # port -> obavezno sa ':'
    if t.startswith('\\\\'):
        return t                                     # vec UNC
    return r'\\%s\%s' % (os.environ.get('COMPUTERNAME', 'localhost'), t)


def _copy_b(fn, dest):
    """Posalji sirovi fajl `fn` na `dest` preko `copy /B` (bez pywin32).
    Prvo direktan copy; ako padne, mapiraj LPT3 na share pa copy (kao rucni test)."""
    rc = subprocess.call(['cmd', '/c', 'copy', '/B', fn, dest])
    if rc == 0:
        return
    # fallback: mapiraj LPT3 -> dest (share) pa copy na port
    subprocess.call(['net', 'use', 'LPT3:', '/delete', '/y'])
    subprocess.call(['net', 'use', 'LPT3:', dest])
    rc2 = subprocess.call(['cmd', '/c', 'copy', '/B', fn, 'LPT3:'])
    subprocess.call(['net', 'use', 'LPT3:', '/delete', '/y'])
    if rc2 != 0:
        raise Exception('copy /B nije uspeo ni direktno ni preko LPT3 (dest=%s)' % dest)


class Printer(object):

    def __init__(self, printer_dev, **kwargs):
        self.dev = printer_dev
        self.data = None
        self.location = kwargs.get('location')

    def print_it(self):
        raise NotImplementedError

    def load_data(self, data):
        raise NotImplementedError


class WinRawPrinter(Printer):
    r"""Windows RAW stampa preko `copy /B` (BEZ pywin32) — salje sirove ESC/POS bajtove
    netaknute, tacno kao rucni `copy /B`. `self.location` = share (npr. 'oki'),
    UNC (\\PC\oki) ili port (LPT1/COM1)."""

    def print_it(self):
        if not self.data:
            raise Exception('No data avaliable for print on {}'.format(self.location))

        with tempfile.NamedTemporaryFile('w+b', delete=False, suffix='.prn') as f:
            f.write(self.data)
            fn = f.name
        try:
            dest = _raw_dest(self.location)
            log.info('RAW print -> %s (zadato: %s)' % (dest, self.location))
            _copy_b(fn, dest)
        finally:
            try:
                os.remove(fn)
            except OSError:
                pass

    def load_data(self, data):
        self.data = data


class DevPrinter(Printer):

    def print_it(self):

        if not self.data:
            raise Exception('No data avaliable for print on {}'.format(self.dev))

        if os.path.exists(self.dev):
            try:
                with open(self.dev, 'wb') as f:
                    f.write(self.data)
            except IOError as e:
                log.error('error writing to printer: {}'.format(e))
                raise Exception('Error printing on: {}'.format(self.dev))
        else:
            raise Exception('No such device: ' + self.dev)

    def load_data(self, data):
        self.data = data


class LPRPrinter(Printer):

    def print_it(self):

        if not self.data:
            raise Exception('No data avaliable for print on {}'.format(self.dev))

        try:
            fn = '/tmp/t_{}.png'.format(next(tempfile._get_candidate_names()))

            t = Ticket(self.data)
            t.generate()

            print_size = t.save(fn)
            subprocess.call(['lpr', fn, '-o', 'media=Custom.{}mm'.format(print_size)])

            os.remove(fn)
        except Exception as e:
            raise Exception('Error printing  on: ' + self.location)

    def load_data(self, data):
        self.data = data.decode('UTF-8')


class MainHandler(tornado.web.RequestHandler):

    def get(self):
        self.write("PremierSBP - printer service")


class PrintHandler(tornado.web.RequestHandler):
    LAST_PRINTED_TICKET = None
    rdb = redis_db()

    def parse_arguments(self):
        response = {}
        for arg in self.request.arguments:
            try:
                response[arg] = self.request.arguments[arg][0].decode('utf-8')
            except:
                response[arg] = self.request.arguments[arg][0]
        return response

    def get(self):

        self.set_header('Access-Control-Allow-Origin', '*')

        try:
            args = self.parse_arguments()

            data = args.get('data')
            ref_code = args.get('ref') or args.get('code')
            dev = args.get('dev')
            if options.printer:
                dev = options.printer

            # === IZMENA: na Windows-u uvek RAW (win32print), ostalo kao pre ===
            if os.name == 'nt':
                printer = WinRawPrinter(dev, location=options.printer)
            elif 'dev' in dev:
                printer = DevPrinter(dev)
            elif 'localhost' in dev:
                printer = WinRawPrinter(dev, location=options.printer)
            elif 'lpr' in dev:
                printer = LPRPrinter(dev)
            else:
                log.critical('No avaliable configuration for device: {}'.format(dev))
                raise Exception('No avaliable configuration for device: {}'.format(dev))

            if data and self.LAST_PRINTED_TICKET != data:
                log.info('************************* BEGIN *************************')

                self.LAST_PRINTED_TICKET = data

                ticket = decompress_text(data)
                printer.load_data(ticket)
                try:
                    printer.print_it()
                except Exception as e:
                    log.critical(e)
                    self.set_status(400)
                    return self.write(status_error('%s not found' % options.printer))

                if config.SAVE_TICKET_TO_LOG:
                    try:
                        log.info(ticket.decode('ascii'))
                    except Exception as e:
                        log.info(ticket)
                        pass

                log.info('REPORTING {}'.format(ref_code))
                print('REPORTING {}'.format(ref_code))
                if ref_code and ref_code.startswith('470'):
                    self.rdb.lpush('lucky6-printed-tickets', pickle.dumps(ref_code))
                elif ref_code and ref_code.startswith('570'):
                    self.rdb.lpush('tombola-printed-tickets', pickle.dumps(ref_code))
                else:
                    self.rdb.lpush('sportsbetting-printed-tickets', pickle.dumps('%s;%s' % (ref_code, str(datetime.datetime.now().replace(microsecond=0)))))

                log.info('************************* END *************************')
                return self.write(status_ok())
            else:
                log.warning('Ticket {} already printed!!!'.format(self.LAST_PRINTED_TICKET))
                self.set_status(400)
                return self.write(status_error('already printed'))

        except Exception as e:
            log.critical(e)
            self.set_status(400)
            self.write(status_error(e))
        finally:
            self.finish()


application = tornado.web.Application([
    (r"/", MainHandler),
    (r"/print/", PrintHandler)

], cookie_secret=config.SECRET_COOKIE, debug=True)

if __name__ == "__main__":

    tornado.options.parse_command_line()
    log = logger('printer-service')

    print(green("[*] PremierSBP printer service started on [{}] using [{}] device".format(config.PRINTER_SERVICE_PORT, options.printer)))
    log.info("PremierSBP printer service started on [{}] using [{}] device".format(config.PRINTER_SERVICE_PORT,  options.printer))

    try:
        # if config.IS_SSL:
        #     app = tornado.httpserver.HTTPServer(application, ssl_options={"certfile": "/etc/sbp/sbp.crt",  "keyfile" : "/etc/sbp/sbp.key"})
        # else:
        app = tornado.httpserver.HTTPServer(application)


        def signal_handler(sig, frame):
            def _shutdown(server):
                log.info('Stopping server')
                server.stop()
                log.info('Shutting down')
                tornado.ioloop.IOLoop.instance().stop()
                log.info('Shut down')

            tornado.ioloop.IOLoop.instance().add_callback_from_signal(_shutdown, app)


        signal.signal(signal.SIGINT, signal_handler)
        signal.signal(signal.SIGTERM, signal_handler)

        app.listen(config.PRINTER_SERVICE_PORT)
        tornado.ioloop.IOLoop.current().start()

    except Exception as e:
        print(red(e))
        log.critical(e)
