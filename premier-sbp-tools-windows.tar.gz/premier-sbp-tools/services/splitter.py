# !/usr/bin/env python

import os
import time
import sys
import re
import subprocess

sys.path.append("/premier-sbp-tools")
sys.path.append("/premier-sbp-tools/services")

BASE_DIR = os.path.abspath(os.path.dirname(__file__))
sys.path.append(BASE_DIR)
sys.path.insert(0, '../../')

import client_config
import config


def get_xinput_id(keyword="Elo"):
    """
    Vrati xinput device ID uredjaja ciji naziv sadrzi `keyword`
    (npr. Elo touchscreen) tako sto ga nadje u `xinput list`.

    VAZNO: xinput ID-jevi se menjaju posle reboota / ponovnog ukljucivanja
    USB-a, pa ih NIKAD ne hardkodujemo. Ovde uvek citamo trenutni ID.
    """
    try:
        out = subprocess.check_output(["xinput", "list"]).decode("utf-8")
    except Exception:
        return ""
    for line in out.splitlines():
        if keyword.lower() in line.lower():
            m = re.search(r"id=(\d+)", line)
            if m:
                return m.group(1)
    return ""


def xinput_remap(touch_id):
    """
    Mapiraj Elo touchscreen na njegov video izlaz.
    Naziv izlaza (VGA-0) proveri sa `xrandr` ako dodir ne pada na pravo mesto
    (moze biti HDMI-0, DP-0, itd.).
    """
    if touch_id:
        os.system('DISPLAY=:0 xinput map-to-output %s VGA-0' % touch_id)


def run():
    if config.LINUX_PLATFORM:
        # Nadji touchscreen (Elo) dinamicki - NE barkod citac.
        # Barkod citac je tastatura i hvata se u JS-u preko keydown-a,
        # njemu --touch-devices NE treba.
        touch_id = get_xinput_id("Elo")
        xinput_remap(touch_id)
        touch_flag = "--touch-devices=%s " % touch_id if touch_id else ""

        # ugasi sve postojece chrome instance
        os.system("pkill -9 -f google-chrome > /dev/null 2>&1")
        time.sleep(2)

        # iskljuci screensaver / DPMS / screen blanking
        os.system('xset s 0 0')
        os.system('xset -dpms')
        os.system('xset s off')

        # pokreni chrome instance
        instance = 1
        for host in client_config.DISPLAY:
            if client_config.DISPLAY[host]:
                for display in client_config.DISPLAY[host]:
                    os.system('rm -rf ~/.config/google-chrome/%s' % instance)
                    time.sleep(.1)

                    os.system('rm -rf ~/.cache/google-chrome')
                    time.sleep(.1)

                    os.system(
                        'google-chrome --window-position={display} {touch}--app={host} '
                        '--kiosk --incognito --disable-web-security '
                        '--disable-gpu --disable-gpu-compositing --disable-dev-shm-usage '
                        '--disable-first-run-ui --no-default-browser-check --disable-translate '
                        '--disable-infobars --disable-features=LocalNetworkAccessChecks'
                        '--user-data-dir=~/.config/google-chrome/{instance} "$@" &'
                        .format(display=display, host=host, instance=instance, touch=touch_flag)
                    )
                    time.sleep(.5)

                    instance += 1

    elif config.WINDOWS_PLATFORM:
        time.sleep(3)
        # run google chrome instances
        instance = 1
        for host in client_config.DISPLAY:
            if client_config.DISPLAY[host]:
                for display in client_config.DISPLAY[host]:
                    os.system(
                        'start chrome --window-position={display} --incognito --kiosk '
                        '--app={host} --disable-first-run-ui --no-default-browser-check --disable-web-security --disable-features=LocalNetworkAccessChecks'
                        '--disable-translate --disable-infobars '
                        '--user-data-dir=c:\\temp{instance}'
                        .format(display=display, host=host, instance=instance)
                    )
                    time.sleep(.5)
                    instance += 1


if __name__ == '__main__':
    run()



