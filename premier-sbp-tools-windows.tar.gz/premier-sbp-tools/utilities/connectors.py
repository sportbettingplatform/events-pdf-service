import sys
#import usb
import serial
import sys

from utilities.string import green


class InputDevice(object):
	
	def __init__(self, devfile, **kw):
		self.device = None
		if 'USB' in devfile:
			self.device = Serial(**kw)
			print(green('[usb] port enabled @ %s' % devfile))
		else:
			self.device = Serial(**kw)
			print(green('[serial] port enabled @ %s' % devfile))
			
	def connection(self):
		if self.device:
			return self.device.connection
		sys.exit("Device not found or cable not plugged in.")


# class Usb(object):
# 	""" USB printer
#
# 	This class describes a printer that natively speaks USB.
#
# 	inheritance:
#
# 	.. inheritance-diagram:: escpos.printer.Usb
# 		:parts: 1
#
# 	"""
#
# 	def __init__(self, idVendor, idProduct, timeout=0, in_ep=0x82, out_ep=0x01, **kw):
# 		"""
# 		:param idVendor: Vendor ID
# 		:param idProduct: Product ID
# 		:param timeout: Is the time limit of the USB operation. Default without timeout.
# 		:param out_ep: Output end point
# 		"""
# 		self.idVendor = idVendor
# 		self.idProduct = idProduct
# 		self.timeout = timeout
# 		self.in_ep = in_ep
# 		self.out_ep = out_ep
# 		self.device = None
# 		self.open()
#
# 	def open(self):
# 		""" Search device on USB tree and set it as device """
# 		self.device = usb.core.find(idVendor=self.idVendor, idProduct=self.idProduct)
# 		if not self.device:
# 			sys.exit("Device not found or cable not plugged in.")
#
# 		check_driver = None
# 		try:
# 			check_driver = self.device.is_kernel_driver_active(0)
# 		except NotImplementedError:
# 			pass
#
# 		if check_driver is None or check_driver:
# 			try:
# 				self.device.detach_kernel_driver(0)
# 			except usb.core.USBError as e:
# 				if check_driver is not None:
# 					print("Could not detatch kernel driver: {0}".format(str(e)))
#
# 		try:
# 			self.device.set_configuration()
# 			self.device.reset()
# 		except usb.core.USBError as e:
# 			print("Could not set configuration: {0}".format(str(e)))
#
# 	def close(self):
# 		""" Release USB interface """
# 		# if self.device:
# 		# 	usb.util.dispose_resources(self.device)
# 		self.device = None
#
# 	def connection(self):
# 		if self.device:
# 			return self.device
# 		sys.exit("Device not found or cable not plugged in.")
#
# 	def write(self, msg):
# 		endpoint = self.device[0][(0, 0)][0]
# 		self.device.write(endpoint.bEndpointAddress, msg, self.timeout)
#
# 	def read(self):
# 		endpoint = self.device[0][(0, 0)][0]
# 		data = self.device.read(endpoint.bEndpointAddress, endpoint.wMaxPacketSize)
# 		return data


class Serial(object):
	""" Serial printer

	This class describes a printer that is connected by serial interface.

	inheritance:

	.. inheritance-diagram:: escpos.printer.Serial
		:parts: 1

	"""

	def __init__(self, devfile="/dev/ttyS0", baudrate=9600, bytesize=serial.EIGHTBITS, timeout=0.5,
				 parity=serial.PARITY_NONE, stopbits=serial.STOPBITS_ONE, **kw):
		"""

		:param devfile:  Device file under dev filesystem
		:param baudrate: Baud rate for serial transmission
		:param bytesize: Serial buffer size
		:param timeout:  Read/Write timeout
		:param parity:   Parity checking
		:param stopbits: Number of stop bits
		:param xonxoff:  Software flow control
		:param dsrdtr:   Hardware flow control (False to enable RTS/CTS)
		"""
		self.devfile = devfile
		self.baudrate = baudrate
		self.bytesize = bytesize
		self.timeout = timeout
		self.parity = parity
		self.stopbits = stopbits
		self.device = None
		self.open()

	def open(self):
		""" Setup serial port and set is as escpos device """
		self.device = serial.Serial(port=self.devfile, baudrate=self.baudrate,
									bytesize=self.bytesize, parity=self.parity,
									stopbits=self.stopbits, timeout=self.timeout, writeTimeout=0.2)

		if self.device and self.device.isOpen():
			try:
				self.device.close()
			except Exception as e:
				print('closing previous connection...')

			self.device = serial.Serial(port=self.devfile, baudrate=self.baudrate,
										bytesize=self.bytesize, parity=self.parity,
										stopbits=self.stopbits, timeout=self.timeout)

		if not self.device:
			sys.exit("Unable to open serial printer on: {0}".format(str(self.devfile)))

	def close(self):
		""" Close Serial interface """
		if self.device:
			self.device.flush()
			self.device.close()
	
	def connection(self):
		if self.device:
			return self.device
		sys.exit("Device not found or cable not plugged in.")
	
	def write(self, msg):
		self.device.write(msg)
	
	def read(self):
		return self.device.read(self.device.inWaiting() or 1)
