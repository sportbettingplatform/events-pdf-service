import redis

rdb = {}


def redis_db(port = 6379, db = 0, decode_response = True):
	return redis.StrictRedis(host='127.0.0.1', port=port, decode_responses=decode_response, db=db, retry_on_timeout=True)
