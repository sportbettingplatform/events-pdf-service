import datetime


def from_timestamp(timestamp):
	return datetime.datetime.fromtimestamp(timestamp)


def time_until_end_of_day():
	dt = datetime.datetime.now()
	return ((24 - dt.hour - 1) * 60 * 60) + ((60 - dt.minute - 1) * 60) + (60 - dt.second)


def to_date(start_time):
	return datetime.datetime.strptime(start_time, "%Y-%m-%d %H:%M:%S")
