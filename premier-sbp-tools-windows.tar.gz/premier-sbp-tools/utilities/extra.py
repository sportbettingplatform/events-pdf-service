import signal
import serial
import logging
import os
import socket
import subprocess
import sys
import time
from logging.handlers import TimedRotatingFileHandler
from threading import Thread
import glob

import psutil
from colorlog import ColoredFormatter
import sendgrid
from sendgrid.helpers.mail import *
from config import SEND_GRID_API

import config
from utilities.string import green, red


def doasync(f):
	def wrapper(*args, **kwargs):
		thr = Thread(target=f, args=args, kwargs=kwargs)
		thr.setDaemon(True)
		thr.start()
	
	return wrapper


def is_internet_on(host="8.8.8.8", port=53, timeout=3):
	"""
	Host: 8.8.8.8 (google-public-dns-a.google.com)
	OpenPort: 53/tcp
	Service: domain (DNS/TCP)
	"""
	
	try:
		socket.setdefaulttimeout(timeout)
		socket.socket(socket.AF_INET, socket.SOCK_STREAM).connect((host, port))
		return True
	except Exception as ex:
		return False


def ip():
	try:
		# First, we use a trick to know the public IP for this machine.
		s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
		s.connect(("8.8.8.8", 80))
		return s.getsockname()[0]
	except Exception as err:
		return '127.0.0.1'


def logger(log2file=None, stream=False):
	# ** path of target log file
	_log2file = '{}.log'.format(log2file if log2file else logging._levelToName[logging.NOTSET].lower())
	
	# ** if file not exists, create empty file
	if not os.path.exists(config.LOG_DIR):
		os.mkdir(config.LOG_DIR)
	
	log = logging.getLogger(log2file.upper())
	if not log.handlers:
		
		log_handler = TimedRotatingFileHandler('{}{}'.format(config.LOG_DIR, _log2file), when="midnight")
		if stream:
			log_handler = logging.StreamHandler(sys.stdout)
		
		# ** format logger
		log_handler.setFormatter(ColoredFormatter(
			"%(log_color)s%(levelname)-8s%(reset)s %(asctime)-6s - %(name)s - %(module)s - %(funcName)s - %(lineno)d ->> %(message)s",
			reset=True,
			log_colors={
				'DEBUG'   : 'cyan',
				'INFO'    : 'green',
				'WARNING' : 'yellow',
				'ERROR'   : 'red',
				'CRITICAL': 'red',
			}
		))
		
		# ** initialize logger object
		log.propagate = False
		log.addHandler(log_handler)
		log.setLevel(logging.DEBUG)
	return log


def start_process(cmd, delay=0.1):
	if config.WINDOWS_PLATFORM:
		cmd[0] += 'w'
		
		# rename path for windows
		cmd[1] = cmd[1].replace("/", "\\")
	
	pid = subprocess.Popen(cmd, stderr=subprocess.STDOUT).pid
	with open(config.PID_DIR + 'app.pids', 'a') as fpids:
		fpids.write('{}\n'.format(pid))
	
	# print("[{}] {}".format(pid, green(' '.join(cmd))))
	time.sleep(delay)


def stop_process(by_name, owner='python3'):
	for proc in psutil.process_iter():
		cmd = proc.cmdline()
		if cmd and owner in cmd[0] and str(by_name) in cmd[1:]:
			psutil.Process(int(proc.pid)).terminate()


def restart_process(by_name=None, by_pid=None, owner='python3'):
	for proc in psutil.process_iter():
		cmd = proc.cmdline()
		
		if by_pid and int(by_pid) == int(proc.pid):
			start_process(cmd, 0.2)
			psutil.Process(int(by_pid)).terminate()
		
		elif by_name:
			if cmd and owner in cmd[0] and by_name in cmd[1:]:
				start_process(cmd, 0.2)
				psutil.Process(int(proc.pid)).terminate()


def kill_all():
	if config.LINUX_PLATFORM:
		os.system('killall stunnel4')
		
		if os.path.isfile(config.PID_DIR + 'app.pids'):
			with open(config.PID_DIR + 'app.pids', 'r') as fpids:
				for p in fpids:
					try:
						psutil.Process(int(p.strip('\n'))).terminate()
						time.sleep(0.05)
					except:
						pass
			
			# pathname = os.path.abspath(os.path.join(dirname, filename))
			# if pathname.startswith(dirname):
			os.remove(config.PID_DIR + 'app.pids')
	
	elif config.WINDOWS_PLATFORM:
		if os.path.isfile(config.PID_DIR + 'app.pids'):
			with open(config.PID_DIR + 'app.pids', 'r') as fpids:
				for p in fpids:
					
					pid = int(p.split(None, 1)[0])
					
					try:
						os.system('taskkill /F /PID %s' % pid)
					except Exception as e:
						print(e)
						pass
	open(config.PID_DIR + 'app.pids', 'w')
	time.sleep(1)


print(red('[*] all services are stopped.'))


def python_version():
	return '%s.%s.%s' % (sys.version_info[0], sys.version_info[1], sys.version_info[2])


def mail_queue(rdb, body):
	rdb.lpush('mail-queue', body)


def send_mail(text=None):
	sg = sendgrid.SendGridAPIClient(api_key=SEND_GRID_API)
	
	try:
		for admin in config.ADMINISTRATORS:
			message = Mail(
				Email('no-replay@' + config.DOMAIN),
				'transaction check',
				Email(admin),
				Content("text/html", text)
			)
			sg.client.mail.send.post(request_body=message.get())
	except Exception as e:
		pass


def is_acceptor_running(acceptor_type):
	for pid in psutil.pids():
		cmdline = psutil.Process(pid).cmdline()
		if "python" in cmdline and "./run.py" in cmdline and acceptor_type in cmdline:
			return True
	return False


def lock_acceptor(acceptor_type):
	if config.LINUX_PLATFORM:
		import fcntl
		file2lock = os.open('{}{}.lock'.format(config.LOCK_DIR, acceptor_type), os.O_CREAT | os.O_TRUNC | os.O_WRONLY)
		try:
			fcntl.lockf(file2lock, fcntl.LOCK_EX | fcntl.LOCK_NB)
		except IOError:
			return False
		return True
	elif config.WINDOWS_PLATFORM:
		try:
			open('{}{}.lock'.format(config.LOCK_DIR, acceptor_type), 'w+')
		except IOError as err:
			return False
		return True
	return False


def serial_ports():
	""" Lists serial port names

		:raises EnvironmentError:
			On unsupported or unknown platforms
		:returns:
			A list of the serial ports available on the system
	"""
	if sys.platform.startswith('win'):
		ports = ['COM%s' % (i + 1) for i in range(256)]
	elif sys.platform.startswith('linux') or sys.platform.startswith('cygwin'):
		# this excludes your current terminal "/dev/tty"
		ports = glob.glob('/dev/tty[A-Za-z]*')
	elif sys.platform.startswith('darwin'):
		ports = glob.glob('/dev/tty.*')
	else:
		raise EnvironmentError('Unsupported platform')
	
	result = []
	for port in ports:
		try:
			s = serial.Serial(port)
			s.close()
			result.append(port)
		except Exception as e:
			pass
	return result


class ServiceExit(Exception):
	"""
	Custom exception which is used to trigger the clean exit
	of all running threads and the main program.
	"""
	pass


class GracefulKiller(object):
	kill_now = False
	
	def __init__(self):
		signal.signal(signal.SIGINT, self.exit_gracefully)
		signal.signal(signal.SIGQUIT, self.exit_gracefully)
		signal.signal(signal.SIGKILL, self.exit_gracefully)
		signal.signal(signal.SIGTERM, self.exit_gracefully)
		signal.signal(signal.SIGHUP, self.exit_gracefully)
	
	def exit_gracefully(self, signum, frame):
		self.kill_now = True
