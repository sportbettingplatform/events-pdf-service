from __future__ import division

from functools import lru_cache
from random import randint


@lru_cache()
def round_by(number):
	return int(number * 10 ** 2 + 0.5) / 10 ** 2


@lru_cache()
def calculate_gain(a, b):
	return round_by(a + b)


@lru_cache()
def calc_percentage(marks, outof):
	try:
		return round(float(marks) / float(outof) * 100, 2)
	except Exception:
		return 0.0


def secs2hours(secs):
	mm, ss = divmod(secs, 60)
	hh, mm = divmod(mm, 60)
	return "%dh:%02dm:%02ds" % (hh, mm, ss)


def secs2mins(secs):
	mm, ss = divmod(secs, 60)
	hh, mm = divmod(mm, 60)
	return "%02dm:%02ds" % (mm, ss)


def bytes2human(num):
	symbols = ('K', 'M', 'G', 'T', 'P', 'E', 'Z', 'Y')
	prefix = {}
	for i, s in enumerate(symbols):
		prefix[s] = 1 << (i + 1) * 10
	for s in reversed(symbols):
		if num >= prefix[s]:
			value = float(num) / prefix[s]
			return '%.1f%s' % (value, s)
	return "%sB" % num


def is_probability_passed(probability):
	return randint(1, 100) < probability


def round_2f(quota):
	return "%.2f" % quota
