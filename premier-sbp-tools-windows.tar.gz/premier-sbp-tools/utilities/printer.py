import tempfile
import json
import os
from PIL import ImageFont
from PIL import Image
from PIL import ImageDraw

from reportlab.lib import units
from reportlab.graphics import renderPM
from reportlab.graphics.barcode import createBarcodeDrawing
from reportlab.graphics.barcode.qr import QrCode
from reportlab.graphics.shapes import Drawing

LOGO_PATH = '/premier-sbp-tools/extras/common/logo/logo.bmp'
FONT_A_PATH = "/premier-sbp-tools/extras/common/fonts/font.ttf"
FONT_B_PATH = "/premier-sbp-tools/extras/common/fonts/fontb.ttf"
strip_width, strip_height = 50, 50

class RasterText(object):
	
	def __init__(self, mtxWidth, mtxHeight, fontWidth, fontHeight, fontSize, barcode_type='Code128'):
		
		self.mtxWidth = mtxWidth
		self.mtxHeight = mtxHeight
		self.fontWidth = fontWidth
		self.fontHeight = fontHeight
		self.fontSize = fontSize
		self.data = None
		self.barcode_type = barcode_type
		self.w = self.mtxWidth * self.fontWidth
		self.h = self.mtxHeight * self.fontHeight + 5000
		
		try:
			self.font = ImageFont.truetype(FONT_A_PATH, self.fontSize)
			self.fontB = ImageFont.truetype(FONT_B_PATH, self.fontSize)
			self.font_double = ImageFont.truetype(FONT_A_PATH, self.fontSize * 2)
			self.fontB_double = ImageFont.truetype(FONT_B_PATH, self.fontSize * 2)
		except Exception as err:
			raise NameError('Missing fonts')
		
		self.img = Image.new("RGBA", (self.w, self.h), (255, 0, 0, 0))
	
	def __str__(self):
		ret = ''
		for r in self.data:
			for c in r:
				ret += c[0]
			ret += '\n'
		return ret
	
	def loads(self, data):
		self.data = data
	
	def final_resize(self, full_height):
		w, h = self.img.size
		self.img = self.img.crop((0, 0, w, full_height))
	
	def resize(self, img, resize = False):
		
		if not resize:
			return img
		
		iw, ih = img.size
		siw = self.w
		sih = ih * siw * 1.0 / iw
		siw = int(siw)
		sih = int(sih)
		return img.resize((siw, sih), resample=1)
	
	@staticmethod
	def crop(img):
		
		try:
			w, h = img.size
			img = img.crop((0, 0, w, h / 2))
			return img
		except:
			return img
	
	def set_logo(self, fileName, x, y):
		return self.set_image(fileName, x, y, True)
	
	def set_image(self, fileName, x, y, resize = False, crop = False):
		
		img = Image.open(fileName, 'r')
		
		if crop:
			try:
				img = self.crop(img)
			except:
				pass
		if resize:
			img = self.resize(img, resize)
		self.img.paste(img, (x, y))
		return img.size
	
	def _generate_barcode(self, value, width, barWidth=0.05 * units.inch, fontSize=30, humanReadable=True):
		
		barcode = createBarcodeDrawing(codeName=self.barcode_type, value=value, barWidth=barWidth, fontSize=fontSize, humanReadable=humanReadable)
		
		drawing_width = width
		barcode_scale = drawing_width / barcode.width
		drawing_height = barcode.height * barcode_scale * 2
		
		drawing = Drawing(drawing_width, drawing_height)
		drawing.scale(barcode_scale, barcode_scale * 2)
		drawing.add(barcode, name='barcode')
		return drawing
	
	def set_barcode(self, code, x, y):
		barcode = self._generate_barcode(value=code, width=800)
		fn = '/tmp/bc_{}.png'.format(code)
		renderPM.drawToFile(barcode, fn, fmt='PNG')
		bcode_size = self.set_image(fn, int(x), int(y), True, True)
		os.remove(fn)
		return bcode_size
	
	def set_qr(self, code):
		return code
		#qr = QrCode(code, )
		#qr.draw()
	
	def rasterize(self, start_row):
		draw = ImageDraw.Draw(self.img)
		for y in range(len(self.data)):
			if not self.data[y]:
				continue
			
			for x in range(len(self.data[y])):
				text, action = self.data[y]
				if text == '_':
					self.add_line(y + start_row - 1)
				elif action == 'doubleHW':
					draw.text(xy=(x * self.fontWidth, (y + start_row) * self.fontHeight), text=text, fill='black', font=self.font_double)
				elif action == 'title':
					draw.text(xy=(-210, (y + start_row) * self.fontHeight), text=text.upper(), fill='black', font=self.fontB_double)
				elif action == 'bold':
					draw.text(xy=(x * self.fontWidth, (y + start_row) * self.fontHeight), text=text, fill='black', font=self.fontB)
				else:
					draw.text(xy=(x * self.fontWidth, (y + start_row) * self.fontHeight), text=text, fill='black', font=self.font)
				break

	def save(self, fname):
		self.img.save(fname)
	
	def add_line(self, row):
		draw = ImageDraw.Draw(self.img)
		draw.text((0, row * self.fontHeight), '-' * self.mtxWidth, 'black', font=self.font_double)
	
	def print_size(self):
		return '{}x{}'.format(72, round(self.img.size[1] / (self.img.size[0] / 80)))


class Ticket(object):
	
	def __init__(self, json_data):
		self.data = json.loads(json_data)
		self.barcode_data = self.data.get('barcode')
		self.qrcode_data = self.data.get('qrcode')
		
		settings = self.data['settings']
		self.mWidth = settings['nrc']
		self.mHeight = settings['nrr']
		self.fWidth = settings['fw']
		self.fHeight = settings['fh']
		self.fSize = settings['fs']
		self.current_row = 0
		self.full_height = 0
		
		self.raster_text = RasterText(self.mWidth, self.mHeight, self.fWidth, self.fHeight, self.fSize)
		self.raster_text.loads(self.data['body'])
	
	def __str__(self):
		idiff = self.raster_text.img.size[1] - self.full_height
		return '''
			W: %s
			H: %s
			FW: %s
			FH: %s
			FS: %s
			IMG SIZE(W,H): %s
			REAL HEIGHT: %s
			diff: %s
			with current rows: %s''' % (
			self.mWidth, self.mHeight, self.fWidth, self.fHeight, self.fSize, self.raster_text.img.size, self.full_height, idiff, self.current_row)
	
	def generate(self):
		
		startr = 1
		try:
			imgsize = self.raster_text.set_logo(LOGO_PATH, 0, 20)
			startr = imgsize[1] / self.fHeight
			startr += 2
			self.current_row = startr
			self.full_height += imgsize[1]
		
		except IOError:
			self.current_row = 1
		
		self.current_row += len(self.data['body'])
		
		self.set_barcode()
		
	#	self.set_qr()
		
		self.raster_text.rasterize(startr)
	
	def set_barcode(self):
		for bc in self.barcode_data:
			b_size = self.raster_text.set_barcode(bc, 0, self.current_row * self.fHeight)
			self.full_height = (self.current_row * self.fHeight) + b_size[1] + 16  # 8dpm * 2mm
	
	def set_qr(self):
		b_size = self.raster_text.set_qr(self.qrcode_data)
		self.full_height = (self.current_row * self.fHeight) + b_size[1] + 16  # 8dpm * 2mm
		
	def save(self, filename):
		self.raster_text.final_resize(self.full_height)
		self.raster_text.save(filename)
		return self.raster_text.print_size()


if __name__ == '__main__':
	t = Ticket(json_data=json.dumps(
		{
			'barcode': '123456789010',
			'qrcode': '123456789010',
		 'settings': {
			'nrc': 42,  # nr-cols
			'nrr': 70,  # nr-rows
			'fw' : 14,  # font-width
			'fh' : 21,  # font-height
			'fs' : 20  # font-size
		 },
		 'body': [['nemanja', True],['nemanja', 'title'], ['_', False]]}
	))
	fn = '/tmp/t_{}.png'.format(next(tempfile._get_candidate_names()))
	
	t.generate()
	
	print_size = t.save(fn)
