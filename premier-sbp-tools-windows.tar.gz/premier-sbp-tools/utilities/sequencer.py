"""
    Sequencer Factory module
"""
import datetime
import random
import time
import uuid

cache = set()
allowed_visual = ['2', '3', '4', '5', '6', '7', '9',
				  'A', 'C', 'D', 'E', 'F', 'G', 'H', 'J', 'K', 'L', 'M', 'N', 'P', 'R', 'S', 'T', 'U', 'V', 'W', 'X','Y', 'Z']


class Sequencer(object):
	"""Sequencer Factory"""
	
	@staticmethod
	def digit32(prefix=''):
		global cache
		
		# example with prefix 69:
		# 69325909263433416124351503931807
		
		if not isinstance(prefix, str):
			prefix = str(prefix)
			
		try:
			size = 22 - len(prefix)
			timestamp = int(time.time())
			for n in range(0, 150):
				seq = int('%s%s%s' % (prefix, str(random.randint(0, 10 ** size)).zfill(size), timestamp))
				if seq not in cache and len(str(seq)) == 32:
					cache.add(seq)
					return seq
		except Exception as err:
			return None
	
	@staticmethod
	def digit(length=12, prefix=''):
		global cache
		
		# example with prefix 4700:
		# 470025962462
		
		if not isinstance(prefix, str):
			prefix = str(prefix)
			
		try:
			size = length - len(prefix)
			for n in range(0, 150):
				seq = int('%s%s' % (prefix, str(random.randint(0, 10 ** size)).zfill(size)))
				if seq not in cache and len(str(seq)) == length:
					cache.add(seq)
					return seq
		except Exception as err:
			print(err)
			return None
	
	@staticmethod
	def alphanum(length=12, prefix=''):
		global cache
		
		# example with prefix 4700:
		# 47003E454433
		
		try:
			len_prefix = len(prefix)
			for n in range(0, 150):
				seq = prefix + ''.join(i for i in str(uuid.uuid4()).upper() if i in allowed_visual)[0:length - len_prefix]
				if seq not in cache and len(seq) == length:
					cache.add(seq)
					return seq
		except Exception as err:
			return None
	
	@staticmethod
	def uuid(prefix='', suffix=''):
		global cache
		
		# example:
		# 2e6bedde-f158-44a8-b7f1-7d2f041d0656
		
		try:
			for n in range(0, 150):
				seq = '%s%s%s' % (prefix, uuid.uuid4(), suffix)
				if seq not in cache:
					cache.add(seq)
					return seq
		except Exception as err:
			return None
	
	@staticmethod
	def uuid_with_ts():
		global cache
		
		# example:
		# a2355660-86fb-430a-a7ec-e2e9168ab2f7-1526467797
		
		try:
			for n in range(0, 150):
				seq = '%s-%s' % (uuid.uuid4(), int(time.time()))
				if seq not in cache:
					cache.add(seq)
					return seq
		except Exception as err:
			return None
