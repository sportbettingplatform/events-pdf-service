from __future__ import division

import json

import requests

import config
from utilities.extra import doasync


@doasync
def async_http_request(method='get', route='', payload=None):
	try:
		return requests.request(method=method, url=route, data=payload, timeout=45)
	except Exception as err:
		print(err)
		return None


def http_request(method='get', route='', payload=None):
	try:
		return requests.request(method=method, url=route, data=payload, timeout=45)
	except Exception as err:
		print(err)
		return None


def status_error(msg=''):
	return json.dumps({
		'status': 'error',
		'message': msg,
	})


def status_ok(msg=None, **kwargs):
	res = {}
	res['status'] = 'ok'
	if msg:
		res['message'] = msg
	for arg in kwargs:
		res[arg] = kwargs[arg]
	return json.dumps(res)
