import base64
import datetime
import decimal
import hashlib
import pickle
import sys
import zlib
import json
from colorama import Fore, Style

import config


def mask_string(text):
	length = len(text)
	if length <= 5:
		return text[0:1] + '*' * (length - 2) + text[-1:]
	elif length <= 10:
		return text[0:2] + '*' * (length - 4) + text[-2:]
	return text[0:3] + '*' * (length - 8) + text[-3:]


def stringify(item):
	return "'%s'" % item


def trim_whitespace(string):
	return "".join(string.split())


def text_ellipsis(text, end=22):
	text = text.strip()
	if len(text) >= end:
		return text[:end-2] + '..'
	return text


def md5encrypt(string):
	m = hashlib.md5()
	m.update(str(config.SECRET_SALT + string).encode())
	return m.hexdigest()


def md5check(encrypted, compare_to):
	return encrypted == md5encrypt(compare_to)


def reindent(string):
	return "\n".join(l.strip() for l in string.strip().split("\n"))


def blue(string):
	return '{}{}{}'.format(Fore.BLUE, string, Style.RESET_ALL)


def yellow(string):
	return '{}{}{}'.format(Fore.YELLOW, string, Style.RESET_ALL)


def cyan(string):
	return '{}{}{}'.format(Fore.CYAN, string, Style.RESET_ALL)


def green(string):
	return '{}{}{}'.format(Fore.GREEN, string, Style.RESET_ALL)


def red(string):
	return '{}{}{}'.format(Fore.RED, string, Style.RESET_ALL)


def render_response(response):
	print('=' * 50)
	print('request ==>', blue(response.url), '\n')
	if response.status_code in [200, 201]:
		print('response ==>', green(response.json()))
	elif response.status_code in [204, 304, 400, 403, 404, 409, 500, 502]:
		print('response ==>', red(response.text))
	else:
		print('response ==>', blue(response.text))
	print('=' * 50)


def __msg_pack_decode(obj):
	if b'__datetime__' in obj:
		return obj.timestamp()
	if b'__date__' in obj:
		return str(obj)
	if b'__decimal__' in obj:
		return float(obj)
	return obj


def __msg_pack_encode(obj):
	"""JSON serializer for objects not serializable by default json code"""
	if isinstance(obj, datetime.datetime):
		return obj.timestamp()
	if isinstance(obj, datetime.date):
		return str(obj)
	if isinstance(obj, decimal.Decimal):
		return float(obj)
	return obj


def json_loads(payload, **kw):
	return json.loads(payload)


def json_dumps(payload, **kw):
	return json.dumps(payload, default=__msg_pack_encode, ensure_ascii=False)


def progress(count, total, status=''):
	bar_len = 100
	filled_len = int(round(bar_len * count / float(total)))
	
	percents = round(100.0 * count / float(total), 1)
	bar = '=' * filled_len + '-' * (bar_len - filled_len)
	
	sys.stdout.write('[%s] %s%s ==> %s\r' % (green(bar), percents, '%', red(status)))
	sys.stdout.flush()


def compress_text(text):
	return base64.b64encode(zlib.compress(text.encode("utf-8"), 9))


def decompress_text(text):
	return zlib.decompress(base64.b64decode(text))


def pickle_loads(payload, default={}):
	try:
		return pickle.loads(payload)
	except:
		return default


def as_string(data):
	try:
		return data.decode('utf-8')
	except:
		return data
